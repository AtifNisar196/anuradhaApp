/* eslint-disable prettier/prettier */
import ActionTypes, {
  SUCCESS,
  PROGRESS,
  FAILED,
  CLEAR,
} from '../../types/AppTypes';
import { persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
// import { courseList } from '../../Api/AppApi';

let INITIAL_STATE = {
  isProgress: false,
  isError: false,
  errorText: '',
  message: '',
  productList: [],
};
function appReducer(state = INITIAL_STATE, action) {
  switch (action.type) {
    case ActionTypes.PRODUCT_LIST + PROGRESS:
      console.log('helllooooo red', action);
      return {
        ...state,
        isProgress: true,
        isError: false,
        errorText: '',
      };
    case ActionTypes.PRODUCT_LIST + SUCCESS:
      console.log('helllooooo sssssss title', action);
      return {
        ...state,
        isProgress: false,
        isError: false,
        errorText: '',
        productList: action.payload.data,
      };

    case ActionTypes.PRODUCT_LIST + FAILED:
      console.log('helllooooo ffff', action);
      return {
        ...state,
        isProgress: false,
        isError: true,
        errorText: action,
      };
    default:
      return state;
  }
}

const persistConfig = {
  key: 'appReducer',
  storage,
  blacklist: ['isProgress', 'isError', 'errorText', 'message'],
  whitelist: [''],
};

export default persistReducer(persistConfig, appReducer);
