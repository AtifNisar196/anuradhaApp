/* eslint-disable prettier/prettier */
import ActionTypes, {
  SUCCESS,
  PROGRESS,
  FAILED,
  CLEAR,
} from '../../types/AuthTypes';
import { persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
// import { courseList } from '../../Api/AppApi';

let INITIAL_STATE = {
  isProgress: false,
  isError: false,
  errorText: '',
  message: '',
  user: undefined,
};
function authReducer(state = INITIAL_STATE, action) {
  switch (action.type) {
    case ActionTypes.LOGIN_USER + PROGRESS:
      console.log('helllooooo red', action);
      return {
        ...state,
        isProgress: true,
        isError: false,
        errorText: '',
      };
    case ActionTypes.LOGIN_USER + SUCCESS:
      console.log('helllooooo sssssss title', action);
      return {
        ...state,
        isProgress: false,
        isError: false,
        errorText: '',
        user: action.payload.data,
      };

    case ActionTypes.LOGIN_USER + FAILED:
      console.log('helllooooo ffff', action);
      return {
        ...state,
        isProgress: false,
        isError: true,
        errorText: action,
      };
    default:
      return state;
  }

}
const persistConfig = {
  key: 'authReducer',
  storage,
  blacklist: ['isProgress', 'isError', 'errorText', 'message'],
  whitelist: [''],
};

export default persistReducer(persistConfig, authReducer);
