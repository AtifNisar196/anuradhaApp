/* eslint-disable prettier/prettier */
const PROGRESS = '_PROGRESS';
const SUCCESS = '_SUCCESS';
const FAILED = '_FAILED';
const CLEAR = '_CLEAR';

export {SUCCESS, PROGRESS, FAILED, CLEAR};

export default Object.freeze({
  LOGIN_USER: 'LOGIN_USER',
  SIGINUP: 'SIGINUP',
  MSG: 'MSG',
  SET_USER: 'SET_USER',
  OTP_VERIFY: 'OTP_VERIFY',
  LOGOUT: 'LOGOUT',
});
