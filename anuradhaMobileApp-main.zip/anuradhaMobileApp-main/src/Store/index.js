import {combineReducers, createStore, applyMiddleware} from 'redux';
import createSagaMiddleware from 'redux-saga';
import {createLogger} from 'redux-logger';
import {persistStore, persistReducer} from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';
/// reducers
import authReducer from './reducer/AuthReducers';
import appReducer from './reducer/AppReducers';
import rootSaga from './root-saga';
///// logger
const loggerMidleware = createLogger();
////// Application Reducers
const rootReducer = combineReducers({
  authReducer,
  appReducer,
  // network
});
const sagaMiddleware = createSagaMiddleware();
const middlewares = [sagaMiddleware];
// if (process.env.NODE_ENV === 'development') {
middlewares.push(loggerMidleware);
// }
const persistConfig = {
  key: 'root',
  storage: AsyncStorage,
  blacklist: ['appReducer', 'authReducer'],
  stateReconciler: autoMergeLevel2,
};
const persistedReducer = persistReducer(persistConfig, rootReducer);

const createStoreWithMiddleware = applyMiddleware(...middlewares);

export let store = createStore(persistedReducer, createStoreWithMiddleware);
sagaMiddleware.run(rootSaga);
export let persistor = persistStore(store);
