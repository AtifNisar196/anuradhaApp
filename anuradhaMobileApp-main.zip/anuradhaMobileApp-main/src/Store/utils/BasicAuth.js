// const BasicAuth = ({ email, password }) => {
//   if (email && password) return { type: 'Basic', value: Buffer.from(`${email}:${password}`).toString('base64') }
//   return {}
// }

// export default BasicAuth
