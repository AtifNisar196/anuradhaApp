/* eslint-disable prettier/prettier */
import {get, post, changeAvatar, put, postForm} from './ApiServices';
export default class MenuServices {
  static async categoryList() {
    let response = await get('/api/category', {});
    return response;
  }
}
