/* eslint-disable prettier/prettier */
import {get, post, changeAvatar, put} from './ApiServices';
import moment from 'moment';

export default class BussinessServices {
    static async getBussinessDetails(payload) {
      let response = await get(`/api/business/id/?businessId=${payload}`,{});
      return response;
    }

}
