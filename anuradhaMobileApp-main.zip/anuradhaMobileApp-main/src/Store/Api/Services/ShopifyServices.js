/* eslint-disable prettier/prettier */
// import Client from 'shopify-buy';




// import axios from 'axios';

// const shopifyApi = axios.create({
//     baseURL: 'https://beautybelleb.myshopify.com/admin/api/2024-07/', // Replace with your store URL and API version
//     headers: {
//         'Content-Type': 'application/json',
//         'X-Shopify-Access-Token': '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', // Replace with your access token
//     },
// });

// export default shopifyApi;


// ShopifyService.js
import axios from 'axios';

const shopifyUrl = 'https://beautybelleb.myshopify.com/admin/api/2024-07'; // Update API version as needed
const apiKey = '0d7144373d0c687beca56b7b3fa5e220';
const apiPassword = 'e9c3a0c4723e9ebcb80507b4effc3363';

const instance = axios.create({
    baseURL: shopifyUrl,
    auth: {
        username: apiKey,
        password: apiPassword,
    },
    headers: {
        'Content-Type': 'application/json',
        'X-Shopify-Access-Token': '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',
    },
});

export const getProducts = async () => {
    try {
        const response = await instance.get('/products.json');
        return response.data.products;
    } catch (error) {
        console.error('Error fetching products:', error);
        throw error;
    }
};

export const getProduct = async (id) => {
    try {
        const response = await instance.get(`/products/${id}.json`);
        return response.data.product;
    } catch (error) {
        console.error('Error fetching product:', error);
        throw error;
    }
};


export const getCategories = async () => {
    try {
        const response = await instance.get('/smart_collections.json');
        return response.data.smart_collections;
    } catch (error) {
        console.error('Error fetching collections:', error);
        throw error;
    }
};

export const getBanners = async (id) => {
    try {
        const response = await instance.get('/metafields.json');
        console.log('getBanners:', response.data);
        return response.data;
    } catch (error) {
        console.error('Error fetching product:', error);
        throw error;
    }
};

// Add more functions as needed





// Initializing a client to return content in the store's primary language
// const client = Client.buildClient({
//     domain: 'beautybelleb.myshopify.com',
//     storefrontAccessToken: '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',
// });


// export async function fetchAllProducts() {

//     return client.collection.fetchAll();
// }
