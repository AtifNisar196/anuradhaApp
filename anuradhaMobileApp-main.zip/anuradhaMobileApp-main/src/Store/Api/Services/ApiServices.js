/* eslint-disable prettier/prettier */
import axios from 'axios';
import { Alert } from 'react-native';
// import { BACK_URL } from '@env';
import { store } from '../../index';
const BACK_URL = 'http://51.83.237.63:4006/';
// const BACK_URL = 'http://test-raftaar.digitrends.us';
// import RNFetchBlob from 'rn-fetch-blob';
const BASE_URL = BACK_URL;
const axiosInstance = axios.create({
  baseURL: BASE_URL,
});

const defaultAPIConfig = {
  showAPIError: false,
};

const HandleResponseError = error => {
  if (error.message === 'Network Error') {
    Alert.alert('Network Error', 'Please check your internet connection');
  } else if (error.message === 'Request failed with status code 401') {
    Alert.alert(
      'Session Expired',
      'Please login again to continue.',
      [
        {
          text: 'Ok',
          onPress: async () => { },
        },
      ],
      { cancelable: false },
    );
  } else if (error.message.startsWith('timeout')) {
    Alert.alert(
      'Request Timed Out',
      'Your request has timed out. Please try again.',
    );
  } else {
    Alert.alert('Error', 'An error occured, please try again later.');
  }
};

const getToken = () => {
  return store.getState().authReducer.loginUser.token;
};

const httpCatch = (route, reject, error, showAPIError) => {
  console.log('HttpCatch: ', route, error.response?.data);

  if (showAPIError === true) {
    HandleResponseError(error);
  }

  reject(error);
};

export const get = async (route, apiConfig = defaultAPIConfig) => {
  console.log('HTTP GET Route: ', route);
  const config = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      token: `${getToken()}`,
    },
  };
  return new Promise((resolve, reject) => {
    axiosInstance
      .get(route, config)
      .then(response => resolve(response.data))
      .catch(error => httpCatch(route, reject, error, apiConfig.showAPIError));
  });
};

export const post = async (route, data, apiConfig = defaultAPIConfig) => {
  // console.log('HTTP POST Route: ', route);
  const config = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      token: `${getToken()}`,
    },
  };
  return new Promise((resolve, reject) => {
    axiosInstance
      .post(route, data, config)
      .then(response => resolve(response.data))
      .catch(error => httpCatch(route, reject, error, apiConfig.showAPIError));
  });
};

export const put = async (route, data, apiConfig = defaultAPIConfig) => {
  // console.log('HTTP POST Route: ', route);
  const config = {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      token: `${getToken()}`,
    },
  };
  return new Promise((resolve, reject) => {
    axiosInstance
      .put(route, data, config)
      .then(response => resolve(response.data))
      .catch(error => httpCatch(route, reject, error, apiConfig.showAPIError));
  });
};

export const del = async (route, data, apiConfig = defaultAPIConfig) => {
  // console.log('HTTP POST Route: ', route);
  const config = {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
      token: `${getToken()}`,
    },
  };
  return new Promise((resolve, reject) => {
    axiosInstance
      .delete(route, config)
      .then(response => resolve(response.data))
      .catch(error => httpCatch(route, reject, error, apiConfig.showAPIError));
  });
};

// export const updateProfile = formData => {
//   console.log(formData, 'DATA');
//   return new Promise((resolve, reject) => {
//     RNFetchBlob.fetch(
//       'PUT',
//       `${BACK_URL}api/business`,
//       {
//         token: `${getToken()}`,
//         'Content-Type': 'multipart/form-data',
//       },
//       formData,
//     )
//       .then(response => resolve(response?.data))
//       .catch(error => reject(error));
//   });
// };

const urlEncode = data => {
  return Object.keys(data)
    .map(key => `${key}=${encodeURIComponent(data[key])}`)
    .join('&');
};
export const postForm = async (route, data, apiConfig = defaultAPIConfig) => {
  // console.log('HTTP POST Route: ', route);
  const config = {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
      token: `${getToken()}`,
    },
  };
  return new Promise((resolve, reject) => {
    axiosInstance
      .post(route, data, config)
      .then(response => resolve(response.data))
      .catch(error => httpCatch(route, reject, error, apiConfig.showAPIError));
  });
};

export const putForm = async (route, data, apiConfig = defaultAPIConfig) => {
  // console.log('HTTP POST Route: ', route);
  const config = {
    method: 'PUT',
    headers: {
      'Content-Type': 'multipart/form-data',
      token: `${getToken()}`,
    },
  };
  return new Promise((resolve, reject) => {
    axiosInstance
      .put(route, data, config)
      .then(response => resolve(response.data))
      .catch(error => httpCatch(route, reject, error, apiConfig.showAPIError));
  });
};

export const delForm = async (route, data, apiConfig = defaultAPIConfig) => {
  // console.log('HTTP POST Route: ', route);
  const config = {
    method: 'DELETE',
    headers: {
      'Content-Type': 'multipart/form-data',
      token: `${getToken()}`,
    },
  };
  return new Promise((resolve, reject) => {
    axiosInstance
      .delete(route, config)
      .then(response => resolve(response.data))
      .catch(error => httpCatch(route, reject, error, apiConfig.showAPIError));
  });
};
