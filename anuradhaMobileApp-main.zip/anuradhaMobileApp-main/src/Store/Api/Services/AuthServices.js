/* eslint-disable prettier/prettier */
import {get, post, changeAvatar, putForm, put, postForm} from './ApiServices';

export default class AuthServices {
  static async resendOtp(payload) {
    let response = await get(`api/otp/resenduserotp/${payload.number}`);
    console.log('responce', response);
    return response;
  }
}
