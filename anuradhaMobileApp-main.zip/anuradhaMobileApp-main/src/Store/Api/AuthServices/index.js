/* eslint-disable prettier/prettier */
import axios from 'axios';
import BarrierAuth from '../../../Utilities/BearerAuth';
import errorHandler from '../../../Utilities/ErrorHandler';
import {BACK_URL} from '@env';

const authorization = ({type, value}) => {
  if (type) {
    return {Authorization: `${type} ${value}`};
  }
  return {};
};

async function loginUser({payload}) {
  try {
    const result = await axios.put(`${BACK_URL}api/auth/user`, payload, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
    console.log('resultresult', result);
    return result;
  } catch (err) {
    return errorHandler(err);
  }
}

export {loginUser};
