/* eslint-disable prettier/prettier */
import ActionTypes, {
  SUCCESS,
  PROGRESS,
  FAILED,
  CLEAR,
} from '../../Types/AuthTypes';

const loginUserStart = data => {
  return {
    type: ActionTypes.LOGIN_USER + PROGRESS,
    payload: data,
  };
};
const loginUserSuccess = data => ({
  type: ActionTypes.LOGIN_USER + SUCCESS,
  payload: data,
});
const loginUserFailure = error => ({
  type: ActionTypes.LOGIN_USER + FAILED,
  error,
});

export {loginUserStart, loginUserFailure, loginUserSuccess};

export default Object({
  loginUserStart,
  loginUserFailure,
  loginUserSuccess,
});
