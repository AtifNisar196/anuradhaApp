/* eslint-disable prettier/prettier */
import { call, put, takeLatest } from 'redux-saga/effects';
import {
    loginUserSuccess,
    loginUserStart,
    loginUserFailure,
} from '../../Actions/AuthActions';
import { showToast } from '../../../Utilities/Helper';
import {
    loginUser,SiginUpUser,OtpVerify,
} from '../../ApiServices/AuthServices';
import ActionTypes, { PROGRESS } from '../../Types/AuthTypes';
import { navigate } from '../../../Navigation/RootNavigation';


export function* loginUserCollectionsAsync(payload) {
    try {
        const response = yield loginUser(payload);
        console.log('response.statusresponse.status', response);
        if (response.data.success === true) {
            yield put(loginUserSuccess(response));
            navigate('Main');
        } else if (response.data.success === false) {
            // console.log(response.data.error, response.data);
            yield put(loginUserFailure(response.data.error || response.data.message));
            showToast({
                message: response.data.message,
                type: 'error',
            });
        }
    } catch (e) {
        // console.log(e);
    }
}

export function* loginUserCollectionsStart() {
    yield takeLatest(
        ActionTypes.LOGIN_USER + PROGRESS,
        loginUserCollectionsAsync,
    );
}

