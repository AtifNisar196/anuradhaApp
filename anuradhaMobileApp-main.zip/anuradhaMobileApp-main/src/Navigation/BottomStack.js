/* eslint-disable prettier/prettier */
/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import * as React from 'react';
import { View, Image } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {
  WhishlistRoutes, CartRoutes, ProfileRoutes,
  HomeRoutes,
} from './BottomTabRoutes';
import images from '../assets/images';
import Colors from '../Themes/Colors';
const Tab = createBottomTabNavigator();

const BottomStack = () => {
  return (
    <Tab.Navigator
      // initialRouteName={HomeRoutes}
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {
          backgroundColor: '#FFF',
          justifyContent: 'center',
          alignItems: 'center',
          alignContent: 'center',
          // paddingBottom: 10,
          height: 65,
        },
        tabBarIcon: ({ focused }) => {
          let iconName;
          if (route.name === 'HomeRoutes') {
            iconName = focused ? images.HomeIcon : images.HomeIcon;
          } else if (route.name === 'ProfileRoutes') {
            iconName = focused ? images.Account : images.Account;
          } else if (route.name === 'CartRoutes') {
            iconName = focused ? images.Message : images.Message;
          } else if (route.name === 'WhishlistRoutes') {
            iconName = focused ? images.FavIcon : images.FavIcon;
          }
          return (
            <View style={{ alignItems: 'center' }}>
              {focused && (
                <View
                  style={{
                    marginTop: 0,
                    height: 7,
                    width: 7,
                    borderRadius: 50,
                    backgroundColor: Colors.primary,
                  }}
                />
              )}
              <View style={{ width: 60, height: 40 }}>
                <Image
                  source={iconName}
                  resizeMode="center"
                  style={{ flex: 1, height: undefined, width: undefined }}
                />
              </View>

            </View>
          );
        },
      })}
    >

      <Tab.Screen name="HomeRoutes" component={HomeRoutes} />
      <Tab.Screen name="CartRoutes" component={CartRoutes} />
      <Tab.Screen name="WhishlistRoutes" component={WhishlistRoutes} />
      <Tab.Screen name="ProfileRoutes" component={ProfileRoutes} />
    </Tab.Navigator>
  );
};

export default BottomStack;
