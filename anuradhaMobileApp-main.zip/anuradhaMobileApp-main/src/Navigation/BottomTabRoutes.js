/* eslint-disable prettier/prettier */
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from '../Screens/HomeStack/HomeScreen';
import ProfileScreens from '../Screens/ProfileStack/ProfileStack';
import CartScreens from '../Screens/CartStack/CartStack';
import WhishlistScreens from '../Screens/WhishlistStack/WhishlistStack';
import ProductDetails from '../Screens/HomeStack/ProductDetails';
import MyCart from '../Screens/HomeStack/MyCart';
const CartStack = createNativeStackNavigator();

const ProfileStack = createNativeStackNavigator();

const WhishlistStack = createNativeStackNavigator();

const HomeStack = createNativeStackNavigator();

const CartRoutes = () => {
  return (
    <CartStack.Navigator
      screenOptions={{
        headerShown: false,
      }}>
      <CartStack.Screen name="Cart" component={CartScreens} />
    </CartStack.Navigator>
  );
};

const HomeRoutes = () => {
  return (
    <HomeStack.Navigator
      screenOptions={{
        headerShown: false,
      }}>
      <HomeStack.Screen name="Home" component={HomeScreen} />
      <HomeStack.Screen name="MyCart" component={MyCart} />
      <HomeStack.Screen name="ProductDetails" component={ProductDetails} />

    </HomeStack.Navigator>
  );
};

const ProfileRoutes = () => {
  return (
    <ProfileStack.Navigator
      screenOptions={{
        headerShown: false,
      }}>
      <ProfileStack.Screen
        name="Profile"
        component={ProfileScreens}
      />

    </ProfileStack.Navigator>
  );
};
const WhishlistRoutes = () => {
  return (
    <WhishlistStack.Navigator
      screenOptions={{
        headerShown: false,
      }}>
      <WhishlistStack.Screen
        name="Whishlist"
        component={WhishlistScreens}
      />

    </WhishlistStack.Navigator>
  );
};

export { WhishlistRoutes, CartRoutes, ProfileRoutes, HomeRoutes };
