/* eslint-disable prettier/prettier */
import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { setNavigationRef } from './RootNavigation';
import Login from '../Screens/RegisterStack/Login';
import Signup from '../Screens/RegisterStack/Signup';
import BottomStack from './BottomStack';
import Signin from '../Screens/RegisterStack/Signin';
import OtpScreen from '../Screens/RegisterStack/OtpScreen';
import InformationScreen from '../Screens/RegisterStack/InformationScreen';
import PasswordRecovery from '../Screens/RegisterStack/PasswordRecovery';
import ResetPassword from '../Screens/RegisterStack/ResetPassword';
import { Use } from 'react-native-svg';
import BootSplash from 'react-native-bootsplash';
import BoardingTwo from '../Screens/RegisterStack/BoardingTwo';
const Stack = createNativeStackNavigator();

const NavigationStack = () => {
  const darkThemeColorScheme = {
    primary: '#F2F2F2',
    secondary: '#F3F3F3',
    background: '#fff',
    backgroundPrimary: '#000000',
    backgroundSecondary: '#323232',
    textColorPrimary: '#2B2B2B',
    textColorSecondary: '#6D6D6D',
    text: '#FFFFFF',
    cardBackgroundPrimary: '',
    cardBackgroundSecondary: '',
    buttonPrimary: '',
    buttonSecondary: '',
    borderPrimary: '',
    borderSecondary: '',
  };

  const lightThemeColorScheme = {
    primary: '#F5672D',
    secondary: '#F3F3F3',
    backgroundPrimary: '#F5672D',
    backgroundSecondary: '#F3F3F3',
    textColorPrimary: '#2B2B2B',
    textColorSecondary: '#6D6D6D',
    textColor: '#FFFFFF',
    cardBackgroundPrimary: '',
    cardBackgroundSecondary: '',
    buttonPrimary: '',
    buttonSecondary: '',
    borderPrimary: '',
    borderSecondary: '',
    text: '#2B2B2B',
    background: '#FFF',
  };
  const user = {};
  // const user = useSelector(state => state.authReducer.loginUser);
  const initialRoute = user == null ? 'Signup' : 'Signup';

  return (
    <>
      <NavigationContainer onReady={() => {
        BootSplash.hide();
      }}>
        <Stack.Navigator initialRouteName="Main">
          <Stack.Screen options={{ headerShown: false }} name="InformationScreen" component={InformationScreen} />
          <Stack.Screen options={{ headerShown: false }} name="BoardingTwo" component={BoardingTwo} />

          <Stack.Screen options={{ headerShown: false }} name="Login" component={Signin} />
          <Stack.Screen options={{ headerShown: false }} name="Signup" component={Signup} />
          <Stack.Screen options={{ headerShown: false }} name="PasswordRecovery" component={PasswordRecovery} />
          <Stack.Screen options={{ headerShown: false }} name="Main" component={BottomStack} />
          <Stack.Screen options={{ headerShown: false }} name="OtpScreen" component={OtpScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
};

export default NavigationStack;
