/* eslint-disable prettier/prettier */
export default {
    primary: '#2C5CC6',
    secondarybg: '#EAEAEA',
    fontSecondary: '#1B1B1B',
};
