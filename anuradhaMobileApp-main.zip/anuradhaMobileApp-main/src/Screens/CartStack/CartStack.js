/* eslint-disable prettier/prettier */
import React from 'react';
import { View, Text } from 'react-native';

const CartScreen = () => {
    return (
        <View>
            <Text>Home Screen</Text>
        </View>
    );
};

export default CartScreen;
