/* eslint-disable prettier/prettier */
import React, { useState } from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    ScrollView,
} from 'react-native';
import Colors from '../../Themes/Colors';
import Icons from 'react-native-vector-icons/FontAwesome6';
import Icon from 'react-native-vector-icons/AntDesign';
import { responsiveSpacing } from '../../Utilities/Common';
import CommonStyles from '../../CommonStyles';
import images from '../../assets/images';

const ProfileScreen = (props) => {
    return (
        <View style={{ flex: 1, backgroundColor: '#EAEAEA' }}>
            <ScrollView>


                <View style={{}}>
                    <View style={{}}>
                        <View style={{
                            flexDirection: 'column', paddingTop: 40, alignItems: 'flex-start', backgroundColor: '#2C5CC6', paddingHorizontal: responsiveSpacing(30),
                        }}>
                            <Image
                                style={{ width: 35, height: 35 }}
                                source={images.ArrowButton}
                                resizeMode="contain"
                            />
                            <View style={{ flexDirection: 'row', alignItems: 'center', width: '100%', paddingTop: 30, paddingBottom: 30 }}>
                                <Icons
                                    name={'circle-user'}
                                    color={'#fff'}
                                    style={{ fontSize: 45 }}
                                />
                                <View>
                                    <Text
                                        style={[
                                            CommonStyles.textSizeAverageX,
                                            CommonStyles.fontMedium,
                                            {
                                                color: '#fff',
                                                textTransform: 'capitalize',
                                                marginLeft: 10,

                                            },
                                        ]}>
                                        Annette Black
                                    </Text>
                                    <Text
                                        style={[
                                            CommonStyles.textSizeAverage,
                                            CommonStyles.fontRegular,
                                            {
                                                color: '#fff',
                                                textTransform: 'capitalize',
                                                marginLeft: 10,

                                            },
                                        ]}>
                                        @myemail.gmail.com
                                    </Text>
                                </View>
                                <Icons
                                    name={'edit'}
                                    color={'#fff'}
                                    style={{ fontSize: 20, left: 140 }}
                                />
                            </View>
                        </View>
                        <View>
                            <Text style={{ textAlign: 'left', padding: 15, fontFamily: 'LibreBaskerville-Regular', color: '#1B1B1B', fontSize: 20 }}>Your Order</Text>
                        </View>
                        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20 }}>
                            <TouchableOpacity>
                                <Image source={images.confirm} style={{ width: 65, height: 65, alignSelf: 'center' }} />
                                <Text style={{ fontFamily: 'DMSans-Medium', textAlign: 'center', padding: 8, color: '#1B1B1B', fontSize: 14 }}>Confirm</Text>
                            </TouchableOpacity>
                            <TouchableOpacity>
                                <Image source={images.delivery} style={{ width: 65, height: 65, alignSelf: 'center' }} />
                                <Text style={{ fontFamily: 'DMSans-Medium', textAlign: 'center', padding: 8, color: '#1B1B1B', fontSize: 14 }}>Delivery</Text>
                            </TouchableOpacity>
                            <TouchableOpacity>
                                <Image source={images.history} style={{ width: 65, height: 65, alignSelf: 'center' }} />
                                <Text style={{ fontFamily: 'DMSans-Medium', textAlign: 'center', padding: 8, color: '#1B1B1B', fontSize: 14 }}>History</Text>
                            </TouchableOpacity>
                            <TouchableOpacity>
                                <Image source={images.ArrowButton} style={{ width: 65, height: 65, alignSelf: 'center' }} />
                                <Text style={{ fontFamily: 'DMSans-Medium', textAlign: 'center', padding: 8, color: '#1B1B1B', fontSize: 14 }}>Packing</Text>
                            </TouchableOpacity>
                        </View>
                        <View>
                            <TouchableOpacity style={{ marginTop: 40, marginHorizontal: 20, paddingVertical: 15, flexDirection: 'row', alignItems: 'center', borderTopWidth: 0.3, borderColor: '#838383' }}>
                                <Icons
                                    name={'user'}
                                    color={'#000'}
                                    style={{ fontSize: 20 }}
                                />
                                <Text style={{ fontFamily: 'DMSans-Medium', textAlign: 'center', padding: 8, color: '#1B1B1B', fontSize: 14 }}>Personal information</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={{ marginHorizontal: 20, paddingVertical: 15, flexDirection: 'row', alignItems: 'center', borderTopWidth: 0.3, borderColor: '#838383' }}>
                                <Icon
                                    name={'Safety'}
                                    color={'#000'}
                                    style={{ fontSize: 20 }}
                                />
                                <Text style={{ fontFamily: 'DMSans-Medium', textAlign: 'center', padding: 8, color: '#1B1B1B', fontSize: 14 }}>Privacy Policy</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={{ marginHorizontal: 20, paddingVertical: 15, flexDirection: 'row', alignItems: 'center', borderTopWidth: 0.3, borderColor: '#838383' }}>
                                <Icon
                                    name={'infocirlceo'}
                                    color={'#000'}
                                    style={{ fontSize: 20 }}
                                />
                                <Text style={{ fontFamily: 'DMSans-Medium', textAlign: 'center', padding: 8, color: '#1B1B1B', fontSize: 14 }}>Help center</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={{ marginHorizontal: 20, paddingVertical: 15, flexDirection: 'row', alignItems: 'center', borderTopWidth: 0.3, borderColor: '#838383' }}>
                                <Icon
                                    name={'setting'}
                                    color={'#000'}
                                    style={{ fontSize: 20 }}
                                />
                                <Text style={{ fontFamily: 'DMSans-Medium', textAlign: 'center', padding: 8, color: '#1B1B1B', fontSize: 14 }}>Setting</Text>
                            </TouchableOpacity>
                        </View>
                        <TouchableOpacity onPress={() => props.navigation.navigate('InformationScreen')} style={{ marginHorizontal: 20, marginTop: 50 }}>
                            <Text style={{ fontFamily: 'DMSans-Bold', textAlign: 'center', padding: 10, borderRadius: 20, color: '#fff', backgroundColor: '#2C5CC6', fontSize: 16 }}>Sign Out</Text>
                        </TouchableOpacity>
                    </View>
                </View>

            </ScrollView >
        </View>
    );
};

export default ProfileScreen;
