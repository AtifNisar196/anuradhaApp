/* eslint-disable prettier/prettier */
import {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  loginUserStart,
} from '../../Store/Actions/AuthActions';
import Toast from 'react-native-simple-toast';

// const _storeData = async (token, user) => {
//   try {
//     await AsyncStorage.setItem('token', token);
//     await AsyncStorage.setItem('user', JSON.stringify(user));
//   } catch (error) {
//     console.log('store data error user signup', error);
//   }
// };
export default () => {
  // const dispatch = useDispatch();

  // const loading = useSelector(state => state.authReducer.loading);
  // const errorText = useSelector(state => state.authReducer.errorText);
  // const message = useSelector(state => state.authReducer.message);
  // const [isSelected, setSelection] = useState(false);

  // useEffect(() => {
  //   // when error occure
  //   if (message) {
  //     Toast.show(message, Toast.LONG);
  //   }
  // }, [message]);


  // const onSubmitLogin = (data, e) => {
  //   console.log('data', data);
  //   dispatch(loginUserStart(data));
  // };

  // return {
  //   loading,
  //   errorText,
  //   onSubmitLogin,
  // };
};
