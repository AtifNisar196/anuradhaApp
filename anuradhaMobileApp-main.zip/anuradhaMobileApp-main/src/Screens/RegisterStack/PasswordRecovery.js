/* eslint-disable prettier/prettier */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import React, { useState } from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    ScrollView,
} from 'react-native';
import { responsiveSpacing } from '../../Utilities/Common';
import CommonStyles from '../../CommonStyles';
import images from '../../assets/images';
import { Formik, Field } from 'formik';
import TextInputField from '../../Components/TextInputField';
import * as yup from 'yup';
const ValidationSchema = yup.object().shape({
    email: yup.string().required('Email is required'),
    password: yup.string().required('Password is required'),
});
const PasswordRecovery = props => {


    const getFormikInput = ({
        type,
        name,
        placeholder,
        isSecure,
        iconName,
        isDisbale,
    }) => {
        return (
            <Field
                component={TextInputField}
                name={name}
                placeholder={placeholder}
                keyboardType={type}
                iconName={iconName}
                isSecure={isSecure}
                isDisbale={isDisbale}
            />
        );
    };

    return (
        <View style={{ flex: 1, backgroundColor: '#EAEAEA' }}>
            <ScrollView>

                <View style={{ paddingHorizontal: responsiveSpacing(30) }}>
                    <View style={{
                        marginTop: responsiveSpacing(40),
                    }}>
                        <View style={{
                            flexDirection: 'row', alignItems: 'center',
                        }}>
                            <Image
                                style={{ width: 50, height: 30 }}
                                source={images.ArrowButton}
                                resizeMode="contain"
                            />
                            <Text
                                style={[
                                    CommonStyles.textSizeBigextra,
                                    {
                                        color: '#1c1c1c',
                                        textAlign: 'center',
                                        marginVertical: 0,
                                        textTransform: 'capitalize',
                                        fontFamily: 'LibreBaskerville-Bold',
                                        marginLeft: 0,
                                    },
                                ]}>
                                Forgot password
                            </Text>
                        </View>
                        <Text
                            style={[
                                CommonStyles.fontRegular,
                                CommonStyles.textSizeAverage,
                                {
                                    color: '#838383',
                                    textAlign: 'left',
                                    marginVertical: 30,
                                },
                            ]}>
                            Enter the email associated with your account and we’ll send an email with code to reset your password
                        </Text>
                    </View>
                    <View>
                        <Formik
                            onSubmit={values => {
                                // onRegister(values);
                            }}
                            validationSchema={ValidationSchema}
                            initialValues={{
                                email: '',
                                password: '',
                                // password: '',
                            }}>
                            {({ handleSubmit, values }) => {
                                return (
                                    <View>
                                        <View style={{
                                            marginTop: responsiveSpacing(40),
                                        }}>
                                            {getFormikInput({
                                                name: 'email',
                                                placeholder: 'Email',
                                                iconName: 'mail-outline',
                                            })}
                                        </View>
                                        <TouchableOpacity
                                            onPress={() => {
                                                props.navigation.navigate('Main');
                                            }}
                                            style={{
                                                width: '100%', backgroundColor: 'transparent', justifyContent: 'center', marginTop: 60, paddingHorizontal: 20, paddingVertical: 12, backgroundColor: '#2C5CC6', flexDirection: 'row', borderRadius: 50,
                                            }}
                                        >
                                            <Text style={{ textAlign: 'center', fontFamily: 'DMSans-Medium', color: '#fff', fontSize: 16 }}>Send Now</Text>
                                        </TouchableOpacity>

                                    </View>
                                );
                            }}
                        </Formik>
                    </View>
                    <View style={{ marginTop: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
                        <Text
                            style={[
                                CommonStyles.fontMedium,
                                CommonStyles.textSizeAverage,
                                {
                                    color: '#838383',
                                    textAlign: 'center',
                                    // marginTop: 30,
                                    flexDirection: 'row',
                                },
                            ]}>
                            Haven't received the code yet? </Text>
                        <TouchableOpacity
                            onPress={() => {
                                props.navigation.navigate('Main');
                            }}
                            style={{ paddingTop: 0 }}>
                            <Text style={[
                                CommonStyles.fontRegular,
                                CommonStyles.textSizeAverage,
                                {
                                    color: '#2C5CC6',
                                    textAlign: 'center',
                                    // marginTop: 20
                                    // marginVertical: 20,
                                },
                            ]}>Send again</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </ScrollView >
        </View >
    );
};

export default PasswordRecovery;
