/* eslint-disable prettier/prettier */
/* eslint-disable no-dupe-keys */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  Image,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { responsiveSpacing } from '../../Utilities/Common';
import CommonStyles from '../../CommonStyles';
import images from '../../assets/images';

const InformationScreen = props => {
  return (

    <View style={{ flex: 1, alignItems: 'center', flexDirection: 'column', justifyContent: 'center' }}>

      <View
        style={{
          width: 300,
          height: 350,
          alignItems: 'center',
          // justifyContent: 'center',
          alignSelf: 'center',
        }}>
        <Image
          style={{ flex: 1, width: 300, height: 300 }}
          source={images.logo}
          resizeMode="contain"
        />
      </View>
      <View>
        <Text style={{ textAlign: 'center', fontFamily: 'LibreBaskerville-Regular', color: '#1B1B1B', fontSize: 32 }}>Beauty Trends</Text>
        <Text style={{ textAlign: 'center', marginVertical: 10, paddingHorizontal: 30, fontFamily: 'DMSans-Regular', color: '#1B1B1B', fontSize: 16 }}>Discover the latest worldwide makeup trends
          and hot products</Text>
      </View>
      <View>
        <Image
          style={{ width: 70, height: 50 }}
          source={images.threedots}
          resizeMode="contain"
        />
      </View>
      <View style={{
        marginTop: responsiveSpacing(30),
        flexDirection: 'row-reverse',
        alignItems: 'flex-start',
        width: '100%',
        paddingHorizontal: 30,
        justifyContent: 'flex-start',
      }}>
        <TouchableOpacity
          onPress={() => {
            props.navigation.navigate('BoardingTwo');
          }}
          style={{
            backgroundColor: 'transparent', paddingHorizontal: 20, paddingVertical: 10, backgroundColor: '#2C5CC6', flexDirection: 'row', borderRadius: 50,
          }}
        >
          <Text style={{ fontFamily: 'DMSans-Medium', color: '#fff', fontSize: 16 }}>Next</Text>
        </TouchableOpacity>
      </View>
    </View >
  );
};

export default InformationScreen;
