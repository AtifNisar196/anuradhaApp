/* eslint-disable prettier/prettier */
/* eslint-disable no-dupe-keys */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    ImageBackground,
    Image,
    TouchableOpacity,
    ScrollView,
} from 'react-native';
import { responsiveSpacing } from '../../Utilities/Common';
import CommonStyles from '../../CommonStyles';
import images from '../../assets/images';
import AppButton from '../../Components/AppButton';

const BoardingTwo = props => {
    return (

        <View style={{ flex: 1, alignItems: 'center', flexDirection: 'column', justifyContent: 'center' }}>

            <View
                style={{
                    width: 300,
                    height: 350,
                    alignItems: 'center',
                    // justifyContent: 'center',
                    alignSelf: 'center',
                }}>
                <Image
                    style={{ flex: 1, width: 300, height: 300 }}
                    source={images.logo}
                    resizeMode="contain"
                />
            </View>
            <View>
                <Text style={{ textAlign: 'center', fontFamily: 'LibreBaskerville-Regular', color: '#1B1B1B', fontSize: 24 }}>Welcome to
                </Text>
                <Text style={{ textAlign: 'center', marginVertical: 5, paddingHorizontal: 30, fontFamily: 'LibreBaskerville-Bold', color: '#1B1B1B', fontSize: 28 }}>
                    Beauty Belle & Beau</Text>
            </View>
            <View>
                <Image
                    style={{ width: 70, height: 50 }}
                    source={images.threedotsnext}
                    resizeMode="contain"
                />
            </View>
            <View style={{
                marginTop: responsiveSpacing(30),
                flexDirection: 'column',
                alignItems: 'flex-start',
                width: '100%',
                paddingHorizontal: 30,
                justifyContent: 'flex-start',
            }}>
                <TouchableOpacity
                    onPress={() => {
                        props.navigation.navigate('Login');
                    }}
                    style={{
                        width: '100%', backgroundColor: 'transparent', justifyContent: 'center', marginBottom: 30, paddingHorizontal: 20, paddingVertical: 15, backgroundColor: '#2C5CC6', flexDirection: 'row', borderRadius: 50,
                    }}
                >
                    <Text style={{ textAlign: 'center', fontFamily: 'DMSans-Medium', color: '#fff', fontSize: 16 }}>Sign In</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onPress={() => {
                        props.navigation.navigate('Login');
                    }}
                    style={{
                        width: '100%', borderWidth: 2, backgroundColor: 'transparent', justifyContent: 'center', paddingHorizontal: 20, paddingVertical: 15, borderColor: '#2C5CC6', flexDirection: 'row', borderRadius: 50,
                    }}
                >
                    <Text style={{ textAlign: 'center', fontFamily: 'DMSans-Medium', color: '#2C5CC6', fontSize: 16 }}>Sign Up</Text>
                </TouchableOpacity>
            </View>
        </View >
    );
};

export default BoardingTwo;
