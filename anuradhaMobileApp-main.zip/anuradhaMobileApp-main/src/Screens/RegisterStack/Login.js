/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  Image,
  ScrollView,
} from 'react-native';
import CommonStyles from '../../CommonStyles';
import Colors from '../../Themes/Colors';
import {responsiveSpacing} from '../../Utilities/Common';
import images from '../../assets/images';
import AppButton from '../../Components/AppButton';

const Login = props => {
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ImageBackground
        source={images.SiginBack}
        resizeMode="cover"
        style={{flexGrow: 1}}>
        <ScrollView>
          <View
            style={{
              width: 170,
              height: 180,
              alignItems: 'center',
              justifyContent: 'center',
              alignSelf: 'center',
              marginTop: 0,
            }}>
            <Image
              style={{flex: 1, width: 170, height: 170}}
              source={images.logo}
              resizeMode="contain"
            />
          </View>
          <View>
            <Text
              style={[
                CommonStyles.fontRegular,
                CommonStyles.textSizeBig,
                {
                  color: '#fff',
                  textAlign: 'center',

                  fontSize: 40,
                  // textTransform: 'uppercase',
                },
              ]}>
              Zerve
            </Text>
            <Text
              style={[
                CommonStyles.fontRegular,
                CommonStyles.textSizeAverageX,
                {
                  color: '#fff',
                  textAlign: 'center',
                  marginVertical: 0,
                  fontSize: 25,
                  marginTop: responsiveSpacing(-20),
                  marginBottom: responsiveSpacing(90),
                  // textTransform: 'uppercase',
                },
              ]}>
              Owner
            </Text>
          </View>
          <View
            style={{paddingHorizontal: responsiveSpacing(20), marginTop: 0}}>
            <View>
              <Text
                style={[
                  CommonStyles.fontRegular,
                  CommonStyles.textSizeBig,
                  {
                    color: '#2B2B2B',
                    textAlign: 'center',
                    marginVertical: responsiveSpacing(40),
                  },
                ]}>
                Lorem ipsum is a dummy
              </Text>
            </View>

            <View>
              <AppButton
                onPress={() => {
                  props.navigation.navigate('Signin');
                }}
                textStyle={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverageX,
                ]}>
                Log in
              </AppButton>
            </View>
            <View style={{marginVertical: responsiveSpacing(30)}}>
              <AppButton
                onPress={() => {
                  props.navigation.navigate('Signup');
                }}
                containerStyles={{borderWidth: 0, backgroundColor: '#F3F3F3'}}
                textStyle={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverageX,
                ]}>
                <Text style={{color: '#2B2B2B'}}>
                  Don’t Have an Account? Sign up!
                </Text>
              </AppButton>
            </View>
            <View>
              <Text
                style={[
                  CommonStyles.fontRegular,
                  CommonStyles.textSizeAverageX,
                  {color: '#6D6D6D', textAlign: 'center', marginTop: 0},
                ]}>
                Language
              </Text>
            </View>
            <View
              style={{
                marginVertical: responsiveSpacing(30),
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingHorizontal: responsiveSpacing(20),
              }}>
              <AppButton
                // onPress = {() => {this.props.navigation.navigate('Signup')}}
                containerStyles={{borderWidth: 0, backgroundColor: '#F3F3F3'}}
                textStyle={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverageX,
                ]}>
                <Text style={{color: '#2B2B2B'}}>English</Text>
              </AppButton>
              <AppButton
                // onPress = {() => {this.props.navigation.navigate('Signup')}}
                containerStyles={{borderWidth: 0, backgroundColor: '#F3F3F3'}}
                textStyle={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverageX,
                ]}>
                <Text style={{color: '#2B2B2B'}}>Greek</Text>
              </AppButton>
              <AppButton
                // onPress = {() => {this.props.navigation.navigate('Signup')}}
                containerStyles={{borderWidth: 0}}
                textStyle={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverageX,
                ]}>
                <Text style={{color: '#fff'}}>Russian</Text>
              </AppButton>
            </View>
            {/* <View>
          <Text
            style={[
              CommonStyles.fontRegular,
              CommonStyles.textSizeAverageX,
              {color: '#6D6D6D', textAlign: 'center', marginTop: 10},
            ]}>
            UX/UI Design by Chris Peratikos
          </Text>
        </View> */}
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

export default Login;
