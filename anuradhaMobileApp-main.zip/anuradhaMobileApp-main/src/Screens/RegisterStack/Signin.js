/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  Image,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { responsiveSpacing } from '../../Utilities/Common';
import LinearGradient from 'react-native-linear-gradient';
import CommonStyles from '../../CommonStyles';
import Colors from '../../Themes/Colors';
import Icons from 'react-native-vector-icons/Ionicons';
import images from '../../assets/images';
import Icon from 'react-native-vector-icons/AntDesign';
import AppButton from '../../Components/AppButton';
import { Formik, Field } from 'formik';
import TextInputField from '../../Components/TextInputField';
import * as yup from 'yup';
import useRegisterStack from './useRegisterStack';
const ValidationSchema = yup.object().shape({
  email: yup.string().required('Email is required'),
  password: yup.string().required('Password is required'),
});
const Signin = props => {



  const getFormikInput = ({
    type,
    name,
    placeholder,
    isSecure,
    iconName,
    isDisbale,
  }) => {
    return (
      <Field
        component={TextInputField}
        name={name}
        placeholder={placeholder}
        keyboardType={type}
        iconName={iconName}
        isSecure={isSecure}
        isDisbale={isDisbale}
      />
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#EAEAEA' }}>
      <ScrollView>

        <View style={{ paddingHorizontal: responsiveSpacing(20) }}>
          <View style={{
            marginTop: responsiveSpacing(80),
            flexDirection: 'row', alignItems: 'center',
          }}>
            <Image
              style={{ width: 50, height: 30 }}
              source={images.ArrowButton}
              resizeMode="contain"
            />
            <Text
              style={[
                CommonStyles.textSizeBigextra,
                {
                  color: '#1c1c1c',
                  textAlign: 'center',
                  marginVertical: 0,
                  textTransform: 'capitalize',
                  fontFamily: 'LibreBaskerville-Bold',
                  marginLeft: 90,
                },
              ]}>
              Sign In
            </Text>

          </View>
          <View>
            <Formik
              onSubmit={values => {
                onRegister(values);
              }}
              validationSchema={ValidationSchema}
              initialValues={{
                email: '',
                password: '',
                // password: '',
              }}>
              {({ handleSubmit, values }) => {
                return (
                  <View>
                    <View style={{
                      marginTop: responsiveSpacing(60),
                    }}>
                      {getFormikInput({
                        name: 'email',
                        placeholder: 'Email',
                        iconName: 'mail-outline',
                      })}
                    </View>
                    <View style={[CommonStyles.mtt20]}>

                      {getFormikInput({
                        name: 'password',
                        placeholder: 'Password',
                        iconName: 'eye-outline',
                      })}
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Text
                        style={[
                          CommonStyles.fontRegular,
                          CommonStyles.textSizeSmallM,
                          {
                            color: '#1c1c1c',
                            textAlign: 'right',
                            marginTop: 10,
                            // alignItems: 'center',
                          },
                        ]}>
                        <Icons
                          name={'checkmark'}
                          color={'#fff'}
                          style={{ fontSize: 15, paddingHorizontal: 10, backgroundColor: 'green', borderRadius: 50, borderWidth: 1 }}
                        />  Remember
                      </Text>
                      <Text
                        style={[
                          CommonStyles.fontRegular,
                          CommonStyles.textSizeSmallM,
                          {
                            color: '#1c1c1c',
                            textAlign: 'right',
                            marginTop: 10,
                          },
                        ]}>
                        Forget Password?
                      </Text>
                    </View>
                    <View style={{
                      marginTop: responsiveSpacing(70),
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      width: '100%',
                      // paddingHorizontal: 30,
                      justifyContent: 'flex-start',
                    }}>
                      <TouchableOpacity
                        onPress={() => {
                          props.navigation.navigate('Main');
                        }}
                        style={{
                          width: '100%', backgroundColor: 'transparent', justifyContent: 'center', marginBottom: 30, paddingHorizontal: 20, paddingVertical: 12, backgroundColor: '#2C5CC6', flexDirection: 'row', borderRadius: 50,
                        }}
                      >
                        <Text style={{ textAlign: 'center', fontFamily: 'DMSans-Medium', color: '#fff', fontSize: 16 }}>Sign In</Text>
                      </TouchableOpacity>

                    </View>
                  </View>
                );
              }}
            </Formik>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                alignSelf: 'center',
                justifyContent: 'space-evenly',
                width: '100%',
                marginTop: responsiveSpacing(0),
                paddingHorizontal: responsiveSpacing(5),
              }}>
              <View
                style={{
                  backgroundColor: '#838383',
                  width: '45%',
                  borderWidth: 1,
                  borderColor: '#838383',
                }} />
              <Text style={[
                CommonStyles.fontRegular,
                CommonStyles.textSizeAverageX,
                {
                  color: '#838383',
                  textAlign: 'right',
                },
              ]}>Or</Text>
              <View
                style={{
                  backgroundColor: '#838383',
                  width: '45%',
                  borderWidth: 1,
                  borderColor: '#838383',
                }} />
            </View>
          </View>


          <View
            style={{
              marginBottom: responsiveSpacing(30),
              flexDirection: 'column',
              justifyContent: 'space-between',
            }}>
            <TouchableOpacity
              onPress={() => {
                // props.navigation.navigate('OtpScreen');
              }}
              style={[
                CommonStyles.mt20,
                {
                  // alignSelf: 'center',
                  width: '98%',
                  // width: '100%',
                  height: 50,
                  backgroundColor: 'transparent',
                  borderRadius: 50,
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'row',
                  borderWidth: 1,
                  borderColor: '#2C5CC6',
                },
              ]}>
              <Icon
                name="apple1"
                color={'#000'}
                size={25}
              />
              <Text
                style={[
                  CommonStyles.textSizeAverageX,
                  CommonStyles.fontMedium,
                  { color: '#2C5CC6', marginLeft: 15 },
                ]}>
                Sign in with Apple
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                // props.navigation.navigate('OtpScreen');
              }}
              style={[
                CommonStyles.mt20,
                {
                  // alignSelf: 'center',
                  width: '98%',
                  // width: '100%',
                  height: 50,
                  backgroundColor: 'transparent',
                  borderRadius: 50,
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'row',
                  borderWidth: 1,
                  borderColor: '#2C5CC6',
                },
              ]}>
              <Icon
                name="google"
                color={'#000'}
                size={25}
              />
              <Text
                style={[
                  CommonStyles.textSizeAverageX,
                  CommonStyles.fontMedium,
                  { color: '#2C5CC6', marginLeft: 15 },
                ]}>
                Sign in with Facebook
              </Text>
            </TouchableOpacity>


          </View>
          <View style={{ marginTop: 0, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
            <Text
              style={[
                CommonStyles.fontMedium,
                CommonStyles.textSizeAverage,
                {
                  color: '#838383',
                  textAlign: 'center',
                  marginVertical: 0,
                  flexDirection: 'row',
                },
              ]}>
              Don't have any account?  </Text>
            <TouchableOpacity
              onPress={() => {
                props.navigation.navigate('Signup');
              }}
              style={{ paddingTop: 0 }}>
              <Text style={[
                CommonStyles.fontRegular,
                CommonStyles.textSizeAverage,
                {
                  color: '#2C5CC6',
                  textAlign: 'center',
                  // marginTop: 20
                  // marginVertical: 20,
                },
              ]}>Register</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default Signin;
