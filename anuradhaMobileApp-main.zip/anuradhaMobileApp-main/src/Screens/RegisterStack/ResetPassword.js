/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ImageBackground,
    Image,
    TouchableOpacity,
    ScrollView,
} from 'react-native';
import CheckBox from '@react-native-community/checkbox';
import { responsiveSpacing } from '../../Utilities/Common';
import LinearGradient from 'react-native-linear-gradient';
import CommonStyles from '../../CommonStyles';
import Colors from '../../Themes/Colors';
import images from '../../assets/images';
import Icon from 'react-native-vector-icons/AntDesign';
import AppButton from '../../Components/AppButton';
import { Formik, Field } from 'formik';
import TextInputField from '../../Components/TextInputField';
import * as yup from 'yup';
import useRegisterStack from './useRegisterStack';
const ValidationSchema = yup.object().shape({
    password: yup.string().required('Password is required'),
});
const ResetPassword = props => {
    const [isSelected, setSelection] = useState(false);


    const getFormikInput = ({
        type,
        name,
        placeholder,
        isSecure,
        iconName,
        isDisbale,
    }) => {
        return (
            <Field
                component={TextInputField}
                name={name}
                placeholder={placeholder}
                keyboardType={type}
                iconName={iconName}
                isSecure={isSecure}
                isDisbale={isDisbale}
            />
        );
    };

    return (
        <View style={{ flex: 1, backgroundColor: '#fff' }}>
            <ImageBackground
                source={images.background}
                resizeMode="cover"
                style={{ flexGrow: 1 }}>
                <ScrollView>

                    <View style={{ paddingHorizontal: responsiveSpacing(30) }}>
                        <View style={{
                            marginTop: responsiveSpacing(80),
                        }}>
                            <Text
                                style={[
                                    CommonStyles.fontBold,
                                    CommonStyles.textSizeBig,
                                    {
                                        color: '#fff',
                                        textAlign: 'center',
                                        marginVertical: 0,
                                        textTransform: 'uppercase',
                                    },
                                ]}>
                                Reset your password
                            </Text>
                            <Text
                                style={[
                                    CommonStyles.fontMedium,
                                    CommonStyles.textSizeAverageX,
                                    {
                                        color: '#dcdcdc',
                                        textAlign: 'center',
                                        marginVertical: 0,
                                    },
                                ]}>
                                Please enter your new password
                            </Text>
                        </View>
                        <View>
                            <Formik
                                onSubmit={values => {
                                    onRegister(values);
                                }}
                                validationSchema={ValidationSchema}
                                initialValues={{
                                    email: '',
                                    password: '',
                                    // password: '',
                                }}>
                                {({ handleSubmit, values }) => {
                                    return (
                                        <View>

                                            <View style={[CommonStyles.mtt20]}>

                                                {getFormikInput({
                                                    name: 'password',
                                                    placeholder: 'Password',
                                                    iconName: 'eye-outline',
                                                })}
                                            </View>
                                            <View>
                                                <Text
                                                    style={[
                                                        CommonStyles.fontMedium,
                                                        CommonStyles.textSizeAverageX,
                                                        {
                                                            color: '#dcdcdc',
                                                            textAlign: 'Left',
                                                            marginTop: 30,
                                                        },
                                                    ]}>
                                                    Your Password must contain
                                                </Text>
                                            </View>
                                            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 20 }}>

                                                <Image source={images.selectedCheck} style={{ width: 30, height: 30 }} />
                                                <Text
                                                    style={[
                                                        CommonStyles.fontMedium,
                                                        CommonStyles.textSizeAverageX,
                                                        {
                                                            color: '#dcdcdc',
                                                            textAlign: 'Left',
                                                            marginLeft: 10,
                                                        },
                                                    ]}>
                                                    At least 6 characters
                                                </Text>
                                            </View>
                                            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 20 }}>

                                                <Image source={images.unselectedCheck} style={{ width: 30, height: 30 }} />
                                                <Text
                                                    style={[
                                                        CommonStyles.fontMedium,
                                                        CommonStyles.textSizeAverageX,
                                                        {
                                                            color: '#dcdcdc',
                                                            textAlign: 'Left',
                                                            marginLeft: 10,
                                                        },
                                                    ]}>
                                                    Contains a number
                                                </Text>
                                            </View>
                                            <LinearGradient
                                                start={{ x: 0.0, y: 0.55 }} end={{ x: 1.5, y: 20.0 }}
                                                locations={[0, 0.1, 0.8]}
                                                colors={['#4155AE', '#125488']}
                                                style={{ borderRadius: 50, marginTop: 20, height: 65, paddingVertical: 20 }}
                                            >
                                                <TouchableOpacity
                                                    onPress={() => {
                                                        handleSubmit();
                                                    }}
                                                    style={[
                                                        // CommonStyles.mt20,
                                                        {
                                                            // alignSelf: 'center',
                                                            width: '100%',

                                                            // borderWidth: 2,
                                                            backgroundColor: 'transparent',

                                                            alignItems: 'center',
                                                            // justifyContent: 'center',
                                                        },
                                                    ]}>
                                                    <Text
                                                        style={[
                                                            CommonStyles.textSizeAverageX,
                                                            CommonStyles.textColorWhite,
                                                            CommonStyles.fontBold,
                                                        ]}>
                                                        Sign Up
                                                    </Text>
                                                </TouchableOpacity>
                                            </LinearGradient>
                                        </View>
                                    );
                                }}
                            </Formik>
                        </View>
                    </View>
                </ScrollView >
            </ImageBackground >
        </View >
    );
};

export default ResetPassword;
