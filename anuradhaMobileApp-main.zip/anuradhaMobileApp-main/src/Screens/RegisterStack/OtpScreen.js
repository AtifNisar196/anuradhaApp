/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  Image,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { responsiveSpacing } from '../../Utilities/Common';
import LinearGradient from 'react-native-linear-gradient';
import CommonStyles from '../../CommonStyles';
import Colors from '../../Themes/Colors';
import images from '../../assets/images';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import { Formik, Field } from 'formik';
import TextInputField from '../../Components/TextInputField';
const OtpScreen = props => {

  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>
      <ImageBackground
        source={images.background}
        resizeMode="cover"
        style={{ flexGrow: 1 }}>
        <ScrollView>

          <View style={{ paddingHorizontal: responsiveSpacing(30) }}>
            <View style={{
              marginTop: responsiveSpacing(120),
            }}>
              <Text
                style={[
                  CommonStyles.fontBold,
                  CommonStyles.textSizeBig,
                  {
                    color: '#fff',
                    textAlign: 'center',
                    marginVertical: 0,
                    textTransform: 'uppercase',
                  },
                ]}>
                Password Recovery
              </Text>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverageX,
                  {
                    color: '#dcdcdc',
                    textAlign: 'center',
                    marginVertical: 0,
                  },
                ]}>
                We have sent the code to your email
              </Text>
            </View>
            <OTPInputView
              style={{ width: '100%', height: 200, paddingHorizontal: 40 }}
              pinCount={4}
              // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
              // onCodeChanged = {code => { this.setState({code})}}
              autoFocusOnLoad
              codeInputFieldStyle={styles.underlineStyleBase}
              codeInputHighlightStyle={styles.underlineStyleHighLighted}
              onCodeFilled={(code => {
                console.log(`Code is ${code}, you are good to go!`);
              })}
            />
            <View />
          </View>
        </ScrollView >
      </ImageBackground >
    </View >
  );
};


const styles = StyleSheet.create({
  borderStyleBase: {
    width: 30,
    height: 45,
  },

  borderStyleHighLighted: {
    borderColor: '#03DAC6',
  },

  underlineStyleBase: {
    width: 60,
    height: 60,
    borderWidth: 0,
    borderBottomWidth: 1,
    borderRadius: 15,
    backgroundColor: '#fff',
    color: '#000',
  },

  underlineStyleHighLighted: {
    borderColor: '#03DAC6',
  },
});
export default OtpScreen;
