/* eslint-disable prettier/prettier */

/* eslint-disable prettier/prettier */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React, { useEffect, useState } from 'react';
import { Dimensions, FlatList, ScrollView, Image, Text, View, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import BannerSlider from '../../Components/carousal';
import Icon from 'react-native-vector-icons/AntDesign';
import images from '../../assets/images';
import NavigationBar from '../../Components/NavigationBar';
import CommonStyles from '../../CommonStyles';
import { useDispatch } from 'react-redux';
import { courseListStart } from '../../Store/actions/AppActions';
import { getBanners, getCategories, getProducts } from '../../Store/Api/Services/ShopifyServices';
const { width } = Dimensions.get('window');
const HomeScreen = (props) => {
    const dispatch = useDispatch();
    const [products, setProducts] = useState([]);
    const [banners, setBanners] = useState([]);
    const [collections, setCollections] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchCollections = async () => {
            try {
                const data = await getCategories();
                console.log('productsss', data[0].image[0]);
                setCollections(data);
                setLoading(false);
            } catch (err) {
                console.error('Error fetching collections:', err);
                setError(err);
                setLoading(false);
            }
        };

        fetchCollections();
    }, []);


    useEffect(() => {
        const fetchData = async () => {
            try {
                const data = await getProducts();
                // console.log('productsss', data);
                setProducts(data);
            } catch (error) {
                console.error('Error fetching products: ', error);
            }
        };
        fetchData();
    }, []);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const data = await getBanners();
                // console.log('productsss', data);
                setBanners(data);
            } catch (error) {
                console.error('Error fetching products: ', error);
            }
        };
        fetchData();
    }, []);
    const data = [
        { id: 1, title: 'Skincare Products', uri: images.roundIcon },
        { id: 1, title: 'Skincare Products', uri: images.roundIcon },
        { id: 1, title: 'Skincare Products', uri: images.roundIcon },
        { id: 1, title: 'Iced Espresso', uri: images.roundIcon },
        { id: 1, title: 'Iced Espresso', uri: images.roundIcon },
        { id: 1, title: 'Iced Espresso', uri: images.roundIcon },

    ];

    const data2 = [
        { id: 1, title: 'Sun Protection', description: 'Organic Vitamin C', uri: images.roundIcon },
        { id: 1, title: 'Sun Protection', description: 'Organic Vitamin C', uri: images.roundIcon },
        { id: 1, title: 'Skincare Products', description: 'Organic Vitamin C', uri: images.roundIcon },
        { id: 1, title: 'Iced Espresso', description: 'Organic Vitamin C', uri: images.roundIcon },
        { id: 1, title: 'Iced Espresso', description: 'Organic Vitamin C', uri: images.roundIcon },
        { id: 1, title: 'Iced Espresso', description: 'Organic Vitamin C', uri: images.roundIcon },

    ];
    return (
        <ScrollView>
            <NavigationBar
                leftHandler={() => { }}
                rightHandler={() => { props.navigation.navigate('MyCart'); }}
                rightHandler2={() => { props.navigation.navigate('BookingCalender'); }}
                leftImage={images.menuIcon}
                rightImage={images.filter}
                rightImage2={images.bellIcon}
                title={'History'}
            />
            <View style={{ marginTop: 0 }} >
                <BannerSlider />

                <View>
                    <Text style={{ textAlign: 'left', padding: 15, fontFamily: 'LibreBaskerville-Regular', color: '#1B1B1B', fontSize: 20 }}>Categories</Text>
                </View>
                {loading ? <ActivityIndicator size="large" color="#0000ff" /> : (
                    <View style={{ paddingLeft: 0 }}>

                        <FlatList
                            showsVerticalScrollIndicator={false}
                            showsHorizontalScrollIndicator={false}
                            data={collections}
                            // numColumns={2}
                            horizontal={true}
                            // columnWrapperStyle={{
                            //   justifyContent: 'flex-start',
                            //   flex: 1,
                            //   flexWrap: 'wrap',
                            //   flexGrow: 1,
                            // }}
                            // numColumns={2}
                            renderItem={({ item }) => {
                                // console.log('colletion item', item);
                                return (
                                    <View
                                        style={{
                                            flex: 1,
                                            alignContent: 'center',
                                            alignItems: 'center',
                                            flexDirection: 'column',
                                            justifyContent: 'center',
                                            // marginRight: ,
                                        }}>
                                        <TouchableOpacity
                                            // onPress={() => setRangeValue2(item)}
                                            style={{

                                                paddingHorizontal: 5,
                                                // paddingVertical: 8,
                                                borderRadius: 10,
                                            }}>
                                            {/* {item.images.map((item) => */}
                                            <Image source={{
                                                uri: item.image.src,
                                            }} style={styles.image} />
                                            {/* )} */}
                                            <Text style={{ fontFamily: 'DMSans-Medium', width: 70, marginTop: 10, textAlign: 'center', color: '#1B1B1B', fontSize: 12 }}>{item.title.slice(0, 20)}</Text>
                                        </TouchableOpacity>
                                    </View>
                                );
                            }} />
                    </View>
                )}

                {products && (
                    <View style={{ paddingLeft: 15 }}>
                        <FlatList
                            showsVerticalScrollIndicator={false}
                            showsHorizontalScrollIndicator={false}
                            data={products}
                            // numColumns={2}
                            horizontal={true}
                            // columnWrapperStyle={{
                            //     justifyContent: 'flex-start',
                            //     flex: 1,
                            //     flexWrap: 'wrap',
                            //     flexGrow: 1,
                            // }}
                            // numColumns={2}
                            renderItem={({ item }) => {
                                return (
                                    <View
                                        style={{
                                            flex: 1,
                                            // alignContent: 'center',
                                            // alignItems: 'center',
                                            flexDirection: 'column',
                                            justifyContent: 'center',
                                            flexWrap: 'nowrap',
                                            marginTop: 30,
                                            // marginRight: ,
                                        }}>
                                        <TouchableOpacity
                                            onPress={() => props.navigation.navigate('ProductDetails')}
                                            style={{

                                                paddingHorizontal: 20,
                                                paddingVertical: 25,
                                                borderRadius: 10,
                                                backgroundColor: '#F8E3E3',
                                                marginHorizontal: 10,
                                            }}>
                                            <Image source={{
                                                uri: item.images[0].src,
                                            }} style={styles.image} />
                                            <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 10, textAlign: 'center', color: '#1B1B1B', fontSize: 12 }}>{item.title.slice(0, 10)}</Text>
                                            <Text style={{ fontFamily: 'DMSans-Regular', marginTop: 10, textAlign: 'center', color: '#1B1B1B', fontSize: 8 }}>{item.src}</Text>
                                            <Text style={{ fontFamily: 'DMSans-Bold', textDecorationLine: 'underline', marginTop: 10, textAlign: 'center', color: '#1B1B1B', fontSize: 12 }}>View All</Text>

                                        </TouchableOpacity>
                                    </View>
                                );
                            }} />
                    </View>
                )}
                <View />
                <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-evenly' }}>
                        {products.map((item) =>

                            <TouchableOpacity
                                onPress={() => props.navigation.navigate('ProductDetails')}
                                style={{
                                    // paddingHorizontal: 20,

                                    borderRadius: 10,
                                    backgroundColor: '#fff',
                                    // marginHorizontal: 10,
                                    marginVertical: 30,
                                    width: '45%',
                                }}>
                                <View style={{ paddingVertical: 15, paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <Icon
                                        name="pluscircle"
                                        color={'#9F9F9F'}
                                        size={25}
                                    />
                                    <Icon
                                        name="hearto"
                                        color={'#9F9F9F'}
                                        size={25}
                                    />
                                </View>
                                <Image source={{ uri: item.images[0].src }} style={styles.image2} />
                                <View style={{ paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <Text style={{ fontFamily: 'DMSans-Medium', marginTop: 10, textAlign: 'left', color: '#1B1B1B', fontSize: 12 }}>{item.title}</Text>
                                </View>
                                <View style={{ paddingBottom: 15, paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <Text style={{ fontFamily: 'DMSans-Regular', marginTop: 10, textAlign: 'center', color: '#838383', fontSize: 10 }}>{'Sun Protection'}</Text>
                                    <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 10, textAlign: 'center', color: '#2C5CC6', fontSize: 12 }}>$16.58</Text>
                                </View>
                            </TouchableOpacity>
                        )}
                    </View>
                </View>
                {/* <View style={{ flexDirection: 'row', width: '100%', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20 }}>

                    <TouchableOpacity
                        // onPress={() => setRangeValue2(item)}
                        style={{
                            // paddingHorizontal: 20,

                            borderRadius: 10,
                            backgroundColor: '#fff',
                            // marginHorizontal: 10,
                            marginVertical: 30,
                            width: '49%',
                        }}>
                        <View style={{ paddingVertical: 15, paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Icon
                                name="pluscircle"
                                color={'#9F9F9F'}
                                size={25}
                            />
                            <Icon
                                name="hearto"
                                color={'#9F9F9F'}
                                size={25}
                            />
                        </View>
                        <Image source={images.productCategory} style={styles.image2} />
                        <View style={{ paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{ fontFamily: 'DMSans-Medium', marginTop: 10, textAlign: 'left', color: '#1B1B1B', fontSize: 12 }}>{'Organic Vitamin C Face Cream'}</Text>
                        </View>
                        <View style={{ paddingBottom: 15, paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Text style={{ fontFamily: 'DMSans-Regular', marginTop: 10, textAlign: 'center', color: '#838383', fontSize: 10 }}>{'Sun Protection'}</Text>
                            <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 10, textAlign: 'center', color: '#2C5CC6', fontSize: 12 }}>$16.58</Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity
                        // onPress={() => setRangeValue2(item)}
                        style={{
                            // paddingHorizontal: 20,

                            borderRadius: 10,
                            backgroundColor: '#fff',
                            // marginHorizontal: 10,
                            marginVertical: 30,
                            width: '49%',
                        }}>
                        <View style={{ paddingVertical: 15, paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Icon
                                name="pluscircle"
                                color={'#9F9F9F'}
                                size={25}
                            />
                            <Icon
                                name="hearto"
                                color={'#9F9F9F'}
                                size={25}
                            />
                        </View>
                        <Image source={images.productCategory} style={styles.image2} />
                        <View style={{ paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{ fontFamily: 'DMSans-Medium', marginTop: 10, textAlign: 'left', color: '#1B1B1B', fontSize: 12 }}>{'Organic Vitamin C Face Cream'}</Text>
                        </View>
                        <View style={{ paddingBottom: 15, paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Text style={{ fontFamily: 'DMSans-Regular', marginTop: 10, textAlign: 'center', color: '#838383', fontSize: 10 }}>{'Sun Protection'}</Text>
                            <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 10, textAlign: 'center', color: '#2C5CC6', fontSize: 12 }}>$16.58</Text>
                        </View>
                    </TouchableOpacity>

                </View> */}
            </View>
        </ScrollView >
    );
};

const styles = StyleSheet.create({
    image2: {
        width: 100,
        height: 100,
        resizeMode: 'cover',
        alignItems: 'center',
        flexDirection: 'row',
        alignSelf: 'center',
    },
    image: {
        width: 70,
        height: 70,
        resizeMode: 'cover',
        alignItems: 'center',
        flexDirection: 'row',
        alignSelf: 'center',
        borderRadius: 50,
    },
});

export default HomeScreen;
