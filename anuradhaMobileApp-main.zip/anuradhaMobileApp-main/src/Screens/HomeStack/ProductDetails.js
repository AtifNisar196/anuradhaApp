/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React, { useState } from 'react';
import { Dimensions, FlatList, ScrollView, Image, Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import BannerSlider from '../../Components/carousal';
import Icon from 'react-native-vector-icons/AntDesign';
import images from '../../assets/images';
import CommonStyles from '../../CommonStyles';
import NavigationBar from '../../Components/NavigationBar';
const { width } = Dimensions.get('window');
const ProductDetails = (props) => {
    const data = [
        { id: '1', uri: images.detailScreen },
        { id: '2', uri: images.detailScreen },
        { id: '3', uri: images.detailScreen },
    ];

    const [currentIndex, setCurrentIndex] = useState(0);

    const viewabilityConfig = {
        itemVisiblePercentThreshold: 50,
    };

    const onViewableItemsChanged = ({ viewableItems }) => {
        if (viewableItems.length > 0) {
            setCurrentIndex(viewableItems[0].index);
        }
    };
    return (
        <ScrollView>
            <NavigationBar
                leftHandler={() => { }}
                rightHandler={() => { props.navigation.navigate('MyCart'); }}
                rightHandler2={() => { props.navigation.navigate('BookingCalender'); }}
                leftImage={images.menuIcon}
                rightImage={images.filter}
                rightImage2={images.bellIcon}
                title={'History'}
            />
            <View style={{ marginTop: 0 }} >
                <FlatList
                    data={data}
                    keyExtractor={item => item.id}
                    horizontal
                    pagingEnabled
                    showsHorizontalScrollIndicator={false}
                    renderItem={({ item }) => (
                        <View style={styles.slide}>
                            <Image source={item.uri} style={styles.image} />
                        </View>
                    )}
                    onViewableItemsChanged={onViewableItemsChanged}
                    viewabilityConfig={viewabilityConfig}
                />
                <View style={styles.pagination}>
                    {data.map((_, index) => (
                        <View
                            key={index}
                            style={[styles.dot, { opacity: currentIndex === index ? 1 : 0.5 }]}
                        />
                    ))}
                </View>
            </View>

            <View style={{ paddingBottom: 10, paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <Text style={{ fontFamily: 'DMSans-Regular', marginTop: 10, textAlign: 'center', color: '#838383', fontSize: 14 }}>{'Sun Protection'}</Text>
                <Text style={{ fontFamily: 'DMSans-Regular', marginTop: 10, textAlign: 'center', color: '#838383', fontSize: 12 }}>$16.58</Text>
            </View>
            <View style={{ paddingBottom: 0, paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <Text style={{ textAlign: 'left', fontFamily: 'LibreBaskerville-Regular', color: '#1B1B1B', fontSize: 20 }}>Red Velvet Lipstick</Text>
                <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 10, textAlign: 'center', color: '#2C5CC6', fontSize: 20 }}>$16.58</Text>
            </View>
            <View>
                <Image source={images.Rating} style={styles.imageRate} />
                <Text style={{ marginLeft: 15, marginTop: 20, fontFamily: 'DMSans-Bold', color: '#1B1B1B', fontSize: 16 }}>Description</Text>
                <Text style={{ paddingHorizontal: 15, fontFamily: 'DMSans-Regular', marginTop: 15, color: '#838383', fontSize: 14 }}>A limited-edition moisture-infused lipstick that delivers on-trend, mega-bold colour and a velvety matte finish in holiday-exclusive shades.</Text>
            </View>
            <View>

                <Text style={{ marginLeft: 15, marginTop: 20, fontFamily: 'DMSans-Bold', color: '#1B1B1B', fontSize: 16 }}>Description</Text>
                <Text style={{ paddingHorizontal: 15, fontFamily: 'DMSans-Regular', marginTop: 15, color: '#838383', fontSize: 14 }}>A limited-edition moisture-infused lipstick that delivers on-trend, mega-bold colour and a velvety matte finish in holiday-exclusive shades.</Text>
            </View>
            <View style={{ paddingVertical: 20, borderTopRightRadius: 20, borderTopLeftRadius: 20, paddingHorizontal: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff' }}>
                <View>
                    <Text style={{ fontFamily: 'DMSans-Regular', marginTop: 0, color: '#838383', fontSize: 10 }}>Total Price</Text>

                    <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 0, color: '#2C5CC6', fontSize: 20 }}>$16.58</Text>
                </View>
                <View>
                    <TouchableOpacity onPress={() => props.navigation.navigate('MyCart')}>
                        <Text style={{ fontFamily: 'DMSans-Bold', textAlign: 'center', padding: 10, borderRadius: 20, color: '#fff', backgroundColor: '#2C5CC6', fontSize: 16 }}>Add To Cart</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </ScrollView >
    );
};

const styles = StyleSheet.create({
    slide: {
        width,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#EAEAEA',
        marginVertical: 20,
    },
    image: {
        width,
        height: 200,
        resizeMode: 'center',
        marginVertical: 50,
    },
    imageRate: {
        // width: 100,
        // flexDirection: 'row',
        paddingHorizontal: 20,
        // alignItems: 'flex-start',
        // alignSelf: 'flex-start',
        marginLeft: 15,
        width: 100,
        height: 20,
        // height: 200,
        resizeMode: 'center',
        // marginVertical: 50,
    },
    pagination: {
        flexDirection: 'row',
        position: 'absolute',
        bottom: 50,
        alignSelf: 'center',
    },
    dot: {
        width: 10,
        height: 10,
        borderRadius: 5,
        backgroundColor: '#2C5CC6',
        margin: 5,
    },
});

export default ProductDetails;
