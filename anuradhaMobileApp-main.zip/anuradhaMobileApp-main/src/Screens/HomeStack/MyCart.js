/* eslint-disable prettier/prettier */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import React, { useState } from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    ScrollView,
} from 'react-native';
import Colors from '../../Themes/Colors';
import Icons from 'react-native-vector-icons/Ionicons';
import { responsiveSpacing } from '../../Utilities/Common';
import CommonStyles from '../../CommonStyles';
import images from '../../assets/images';
import { Formik, Field } from 'formik';
import NavigationBar from '../../Components/NavigationBar';
import TextInputField from '../../Components/TextInputField';
import * as yup from 'yup';
const ValidationSchema = yup.object().shape({
    email: yup.string().required('Email is required'),
    password: yup.string().required('Password is required'),
});
const MyCart = props => {



    return (
        <View style={{ flex: 1, backgroundColor: '#EAEAEA' }}>
            <ScrollView>


                <View style={{ paddingHorizontal: responsiveSpacing(30) }}>
                    <View style={{
                        marginTop: responsiveSpacing(40),
                    }}>
                        <View style={{
                            flexDirection: 'row', alignItems: 'center',
                        }}>
                            <Image
                                style={{ width: 35, height: 35 }}
                                source={images.ArrowButton}
                                resizeMode="contain"
                            />
                            <Text
                                style={[
                                    CommonStyles.textSizeBigextra,
                                    {
                                        color: '#1c1c1c',
                                        textAlign: 'center',
                                        marginVertical: 0,
                                        textTransform: 'capitalize',
                                        fontFamily: 'LibreBaskerville-Bold',
                                        marginLeft: 60,
                                    },
                                ]}>
                                My Cart
                            </Text>
                        </View>

                    </View>
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderColor: '#838383', borderBottomWidth: 0.5 }}>
                        <View>
                            <Icons
                                name={'checkmark'}
                                color={'#fff'}
                                style={{ fontSize: 15, padding: 3, backgroundColor: 'green', borderRadius: 50 }}
                            />
                        </View>
                        <View>
                            <Image source={images.productbg} resizeMode="center" style={{ width: 150, height: 150, borderRadius: 20 }} />
                        </View>
                        <View >
                            <Text style={{ marginBottom: 10, fontFamily: 'DMSans-Medium', color: '#1B1B1B', fontSize: 16 }}>Red Velvet Lipstick</Text>
                            <Text style={{ fontFamily: 'DMSans-Regular', marginTop: 0, color: '#838383', fontSize: 12 }}>Color: Red</Text>
                            <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 10, color: '#2C5CC6', fontSize: 16 }}>$ 16.50</Text>
                            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>

                                <Icons
                                    name={'remove-sharp'}
                                    color={'#000'}
                                    style={{ fontSize: 20 }} />
                                <Text style={{ fontFamily: 'DMSans-Medium', color: '#1B1B1B', fontSize: 16, marginHorizontal: 10 }}>1</Text>
                                <Icons
                                    name={'add'}
                                    color={'#000'}
                                    style={{ fontSize: 20 }} />
                            </View>

                        </View>
                        <View >
                            <Icons
                                name={'close-sharp'}
                                color={'#838383'}
                                style={{ fontSize: 25 }} />
                        </View>
                    </View>

                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderColor: '#838383', borderBottomWidth: 0.5 }}>
                        <View>
                            <Icons
                                name={'checkmark'}
                                color={'#fff'}
                                style={{ fontSize: 15, padding: 3, backgroundColor: 'green', borderRadius: 50 }}
                            />
                        </View>
                        <View>
                            <Image source={images.productbg} resizeMode="center" style={{ width: 150, height: 150, borderRadius: 20 }} />
                        </View>
                        <View >
                            <Text style={{ marginBottom: 10, fontFamily: 'DMSans-Medium', color: '#1B1B1B', fontSize: 16 }}>Red Velvet Lipstick</Text>
                            <Text style={{ fontFamily: 'DMSans-Regular', marginTop: 0, color: '#838383', fontSize: 12 }}>Color: Red</Text>
                            <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 10, color: '#2C5CC6', fontSize: 16 }}>$ 16.50</Text>
                            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>

                                <Icons
                                    name={'remove-sharp'}
                                    color={'#000'}
                                    style={{ fontSize: 20 }} />
                                <Text style={{ fontFamily: 'DMSans-Medium', color: '#1B1B1B', fontSize: 16, marginHorizontal: 10 }}>1</Text>
                                <Icons
                                    name={'add'}
                                    color={'#000'}
                                    style={{ fontSize: 20 }} />
                            </View>

                        </View>
                        <View >
                            <Icons
                                name={'close-sharp'}
                                color={'#838383'}
                                style={{ fontSize: 25 }} />
                        </View>
                    </View>
                    <View>
                        <Text style={{ marginVertical: 20, fontFamily: 'DMSans-Medium', color: '#1B1B1B', fontSize: 16 }}>Payment Method</Text>
                        <TouchableOpacity style={{ paddingVertical: 15, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', backgroundColor: '#fff', borderRadius: 40 }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                                <Icons
                                    name={'card'}
                                    color={'#2C5CC6'}
                                    style={{ fontSize: 25 }} />
                                <Text style={{ marginHorizontal: 20, fontFamily: 'DMSans-Medium', color: '#838383', fontSize: 14 }}>Credit Card</Text>
                            </View>
                            <Icons
                                name={'arrow-forward'}
                                color={'#838383'}
                                style={{ fontSize: 25 }} />
                        </TouchableOpacity>
                    </View>

                </View>
                <View style={{ paddingVertical: 20, marginTop: 50, borderTopRightRadius: 20, borderTopLeftRadius: 20, paddingHorizontal: 30, flexDirection: 'column', justifyContent: 'space-between', backgroundColor: '#fff' }}>

                    <View>
                        <TouchableOpacity style={{ paddingVertical: 15, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', backgroundColor: '#EDEDED', borderRadius: 40 }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                                <Icons
                                    name={'card'}
                                    color={'#2C5CC6'}
                                    style={{ fontSize: 25 }} />
                                <Text style={{ marginHorizontal: 20, fontFamily: 'DMSans-Medium', color: '#838383', fontSize: 14 }}>Credit Card</Text>
                            </View>
                            <Icons
                                name={'arrow-forward'}
                                color={'#838383'}
                                style={{ fontSize: 25 }} />
                        </TouchableOpacity>
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginVertical: 10 }}>
                        <Text style={{ fontFamily: 'DMSans-Medium', marginTop: 0, color: '#838383', fontSize: 14 }}>Total Price</Text>
                        <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 0, color: '#000', fontSize: 15 }}>$16.58</Text>
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginVertical: 10 }}>
                        <Text style={{ fontFamily: 'DMSans-Medium', marginTop: 0, color: '#838383', fontSize: 14 }}>Total Price</Text>
                        <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 0, color: '#000', fontSize: 15 }}>$16.58</Text>
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginVertical: 10 }}>
                        <Text style={{ fontFamily: 'DMSans-Medium', marginTop: 0, color: '#838383', fontSize: 14 }}>Total Price</Text>
                        <Text style={{ fontFamily: 'DMSans-Bold', marginTop: 0, color: '#2C5CC6', fontSize: 20 }}>$16.58</Text>
                    </View>
                    <View>
                        <Text style={{ fontFamily: 'DMSans-Bold', textAlign: 'center', padding: 10, borderRadius: 20, color: '#fff', backgroundColor: '#2C5CC6', fontSize: 16 }}>Add To Cart</Text>
                    </View>
                </View>
            </ScrollView >
        </View >
    );
};

export default MyCart;
