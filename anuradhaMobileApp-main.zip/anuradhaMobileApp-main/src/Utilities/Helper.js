import Toast from 'react-native-toast-message';

export const showToast = ({
  message,
  type,
  duration = 2000,
  onPress = () => Toast.hide(),
  autoHide = true,
}) => {
  return Toast.show({
    text1: message,
    type: type,
    onPress: () => {
      onPress();
      Toast.hide();
    },
    visibilityTime: duration,
    autoHide: autoHide,
  });
};

export const getTabIndex = (arr, name) => {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].title == name) {
      return i;
    }
  }
};
