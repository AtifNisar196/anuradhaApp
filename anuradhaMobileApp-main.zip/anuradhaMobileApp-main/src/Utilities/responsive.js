import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';

export const w = widthPercentageToDP;
export const h = heightPercentageToDP;
