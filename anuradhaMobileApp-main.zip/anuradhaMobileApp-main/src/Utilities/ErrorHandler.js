// import { myTokenRefreshStart } from "../actions/AuthActions";
import {store} from '../index';
import {showToast} from '../Utilities/Helper';
function errorHandler(err, payload) {
  if (err) {
    // client received an error response (5xx, 4xx)
    console.log(err.response, 'jwtresponse');
    if (err.response.data) {
      console.log('payloaderror', err.message);
      //   store.dispatch(myTokenRefreshStart(payload))
    }
    showToast({
      message: err.message,
      type: 'error',
    });
    console.log(err, 'errorhandleresponsessss12');
    return err.response || err;
  } else if (err.request) {
    // console.log(err.request, 'err.request');
    // client never received a response, or request never left
    return {
      status: 400,
      data: {
        error: 'The request timed out.',
      },
    };
  } else {
    // anything else
    console.log(err, 'err');
    showToast({
      message: err.message,
      type: 'error',
    });
    return err;
  }
}
export default errorHandler;
