import {Dimensions} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import ImagePicker from 'react-native-image-crop-picker';
import ImageResizer from 'react-native-image-resizer';
import Config from 'react-native-config'

const imageResizerFunc = async (path, wAr, hAr, type, quality, images) => {
  try {
    const imageResizeResponse = await ImageResizer.createResizedImage(
      path,
      wAr,
      hAr,
      type,
      quality,
    );
    return {
      uri: imageResizeResponse.path,
      type: images.mime,
      name: imageResizeResponse.name,
    };
  } catch (e) {
    console.log('image resizer error', e);
  }
};

const imageModify = (images) => {
  const windowWidth = Dimensions.get('window').width;
  const windowHeight = Dimensions.get('window').height;
  let widthSet;
  let heightSet;
  if (!images.cropRect) {
    const calculateWidth = images.width * (windowHeight / images.height);
    const calculateHeight = images.height * (windowWidth / images.width);
    if (images.height > images.width) {
      widthSet = calculateWidth;
      heightSet = windowHeight;
    } else if (images.height < images.width) {
      widthSet = windowWidth;
      heightSet = calculateHeight;
    }
    return {
      widthSet,
      heightSet,
    };
  } else {
    const calculateHeight =
      images.cropRect.height * (windowWidth / images.cropRect.width);
    const calculateWidth =
      images.cropRect.width * (windowHeight / images.cropRect.height);
    if (images.cropRect.height > images.cropRect.width) {
      widthSet = calculateWidth;
      heightSet = windowHeight;
    } else if (images.cropRect.height < images.cropRect.width) {
      widthSet = windowWidth;
      heightSet = calculateHeight;
    }
    return {
      widthSet,
      heightSet,
    };
  }
};

export const takeImage = async () => {
  try {
    const captureImage = await ImagePicker.openCamera({
      mediaType: 'photo',
      width: wp(90),
      height: hp(30),
      cropping: true,
    });
    if (!captureImage.cropRect) {
      const {widthSet, heightSet} = imageModify(captureImage);
      return imageResizerFunc(
        captureImage.path,
        widthSet,
        heightSet,
        'JPEG',
        80,
        captureImage,
      );
    } else if (captureImage.cropRect) {
      const {widthSet, heightSet} = imageModify(captureImage);
      return imageResizerFunc(
        captureImage.path,
        widthSet,
        heightSet,
        'JPEG',
        80,
        captureImage,
      );
    }
  } catch (e) {
    console.log('take photo', e);
  }
};

export const selectImage = async () => {
  try {
    const images = await ImagePicker.openPicker({
      mediaType: 'photo',
      cropping: true,
      width: wp(90),
      height: hp(30),
      // multiple: true,
    });
    if (!images.cropRect) {
      const {widthSet, heightSet} = imageModify(images);
      return imageResizerFunc(
        images.path,
        (widthSet = 300),
        (heightSet = 400),
        'JPEG',
        80,
        images,
      );
    } else if (images.cropRect) {
      const {widthSet, heightSet} = imageModify(images);
      console.log('image select')
      return imageResizerFunc(
        images.path,
        widthSet,
        heightSet,
        'JPEG',
        80,
        images,
      );
    }
  } catch (e) {
    console.log('select photo', e);
  }
};

export const localImages = (images) => {
  const filterPhoneImages = images.filter((item) => typeof item === 'object');
  return filterPhoneImages.map((item) => item.uri);
};

export const serverImages = (images) => {
  const filterServerImages = images.filter((item) => typeof item === 'string');
  return filterServerImages.map((item) => Config.IMAGE_URL + item);
};

export const sliderImagesMerge = (images) => {
  const filterPhoneImages = images.filter((item) => typeof item === 'object');
  const filterServerImages = images.filter((item) => typeof item === 'string');
  const convertToServerImages = filterServerImages.map(
    (item) => Config.IMAGE_URL + item,
  );
  const convertToPhoneImages = filterPhoneImages.map((item) => item.uri);

  return convertToServerImages.concat(convertToPhoneImages);
};
