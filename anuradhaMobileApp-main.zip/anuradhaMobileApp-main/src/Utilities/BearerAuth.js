const BearerAuth = ({token, accessToken, idToken, forgetToken}) =>{
    return({
    type: 'Bearer',
    value: token || accessToken || idToken || forgetToken,
  })};
  
  export default BearerAuth;