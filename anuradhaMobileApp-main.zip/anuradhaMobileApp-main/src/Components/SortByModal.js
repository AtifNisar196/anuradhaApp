import React, {useState} from 'react';
import {
  Alert,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  Pressable,
  View,
  Image,
} from 'react-native';
import CommonStyles from '../CommonStyles';
import {responsiveSpacing} from '../Utilities/Common';
import Colors from '../Themes/Colors';
import * as RootNavigation from '../Navigation/RootNavigation';
import images from '../assets/images';
import AppButton from '../Components/AppButton';

const SortByModal = ({
  onRequestClose,
  setModalVisible,
  modalVisible,
  closeModal,
}) => {
  // const onCloseModal = () => {
  //   console.log('close');
  //   setModalVisible(false);
  // };

  const [modalVisibleClose, setModalVisibleClose] = useState(false);
  return (
    <View style={styles.centeredView}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => closeModal()}
        onDismiss={() => closeModal()}
        // onRequestClose={onCloseModal}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <View
              style={{
                flexDirection: 'row',
                // justifyContent: 'space-evenly',
                // alignItems: 'center',
                paddingHorizontal: responsiveSpacing(10),
                marginVertical: responsiveSpacing(20),
              }}>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeBig,
                  {color: '#2B2B2B'},
                ]}>
                Sorty By
              </Text>
            </View>
            <View
              style={{
                paddingHorizontal: responsiveSpacing(0),
                marginBottom: 0,
                marginTop: responsiveSpacing(10),
              }}>
              <View
                style={{
                  backgroundColor: '#F3F3F3',
                  marginBottom: responsiveSpacing(20),

                  paddingVertical: responsiveSpacing(0),
                  borderRadius: 10,
                }}>
                <View
                  style={{
                    paddingHorizontal: responsiveSpacing(10),
                    // borderLeftWidth: 2,
                    // borderColor: '#F5672D',
                  }}>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                    }}>
                    <Text
                      style={[
                        CommonStyles.fontMedium,
                        CommonStyles.textSizeAverageX,
                        {color: '#2B2B2B'},
                      ]}>
                      Alphabetical Order
                    </Text>
                  </View>

                  <View
                    style={{
                      marginVertical: responsiveSpacing(10),
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      paddingHorizontal: 0,
                    }}>
                    <View style={{flex: 1}}>
                      <AppButton
                        onPress={() => {
                          closeModal(), RootNavigation.navigate('Home');
                        }}
                        containerStyles={{
                          borderWidth: 0,
                          borderRadius: 10,
                          paddingHorizontal: responsiveSpacing(30),
                          backgroundColor: '#F5672D',
                          // width: '100%',
                        }}
                        textStyle={[
                          CommonStyles.fontMedium,
                          CommonStyles.textSizeAverageX,
                        ]}>
                        <Text style={{color: '#fff', fontSize: 12}}>
                          A to Z
                        </Text>
                      </AppButton>
                    </View>
                    <View style={{flex: 1, marginLeft: 10}}>
                      <AppButton
                        onPress={() => closeModal()}
                        containerStyles={{
                          // borderWidth: 1,
                          // marginTop: responsiveSpacing(10),
                          borderRadius: 10,
                          backgroundColor: '#fff',
                          marginBottom: responsiveSpacing(20),
                          paddingHorizontal: responsiveSpacing(30),
                        }}
                        textStyle={[
                          CommonStyles.fontMedium,
                          CommonStyles.textSizeAverageX,
                        ]}>
                        <Text
                          style={{
                            color: '#000',
                            fontSize: 12,
                            textAlign: 'left',
                          }}>
                          A to Z
                        </Text>
                      </AppButton>
                    </View>
                  </View>
                </View>
              </View>
              <View
                style={{
                  paddingHorizontal: responsiveSpacing(10),
                  // borderLeftWidth: 2,
                  // borderColor: '#F5672D',
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                  }}>
                  <Text
                    style={[
                      CommonStyles.fontMedium,
                      CommonStyles.textSizeAverageX,
                      {color: '#2B2B2B'},
                    ]}>
                    Distance
                  </Text>
                </View>

                <View
                  style={{
                    marginVertical: responsiveSpacing(10),
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingHorizontal: 0,
                  }}>
                  <View style={{flex: 1, marginRight: 10}}>
                    <AppButton
                      onPress={() => closeModal()}
                      containerStyles={{
                        // borderWidth: 1,
                        // marginTop: responsiveSpacing(10),
                        borderRadius: 10,
                        backgroundColor: '#fff',
                        marginBottom: responsiveSpacing(20),
                        paddingHorizontal: responsiveSpacing(30),
                      }}
                      textStyle={[
                        CommonStyles.fontMedium,
                        CommonStyles.textSizeAverageX,
                      ]}>
                      <Text
                        style={{
                          color: '#000',
                          fontSize: 12,
                          textAlign: 'left',
                        }}>
                        Closest
                      </Text>
                    </AppButton>
                  </View>
                  <View style={{flex: 1}}>
                    <AppButton
                      onPress={() => {
                        closeModal(), RootNavigation.navigate('Home');
                      }}
                      containerStyles={{
                        borderWidth: 0,
                        borderRadius: 10,
                        paddingHorizontal: responsiveSpacing(30),
                        backgroundColor: '#F5672D',
                        // width: '100%',
                      }}
                      textStyle={[
                        CommonStyles.fontMedium,
                        CommonStyles.textSizeAverageX,
                      ]}>
                      <Text style={{color: '#fff', fontSize: 12}}>
                        Furthest
                      </Text>
                    </AppButton>
                  </View>
                </View>
              </View>

              <View
                style={{
                  paddingHorizontal: responsiveSpacing(10),
                  // borderLeftWidth: 2,
                  // borderColor: '#F5672D',
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                  }}>
                  <Text
                    style={[
                      CommonStyles.fontMedium,
                      CommonStyles.textSizeAverageX,
                      {color: '#2B2B2B'},
                    ]}>
                    Price
                  </Text>
                </View>

                <View
                  style={{
                    marginVertical: responsiveSpacing(10),
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingHorizontal: 0,
                  }}>
                  <View style={{flex: 1}}>
                    <AppButton
                      onPress={() => {
                        closeModal(), RootNavigation.navigate('Home');
                      }}
                      containerStyles={{
                        borderWidth: 0,
                        borderRadius: 10,
                        paddingHorizontal: responsiveSpacing(30),
                        backgroundColor: '#fff',
                        // width: '100%',
                      }}
                      textStyle={[
                        CommonStyles.fontMedium,
                        CommonStyles.textSizeAverageX,
                      ]}>
                      <Text style={{color: '#000', fontSize: 12}}>Lowest</Text>
                    </AppButton>
                  </View>
                  <View style={{flex: 1, marginLeft: 10}}>
                    <AppButton
                      onPress={() => closeModal()}
                      containerStyles={{
                        // borderWidth: 1,
                        // marginTop: responsiveSpacing(10),
                        borderRadius: 10,
                        backgroundColor: '#fff',
                        marginBottom: responsiveSpacing(20),
                        paddingHorizontal: responsiveSpacing(30),
                      }}
                      textStyle={[
                        CommonStyles.fontMedium,
                        CommonStyles.textSizeAverageX,
                      ]}>
                      <Text
                        style={{
                          color: '#000',
                          fontSize: 12,
                          textAlign: 'left',
                        }}>
                        Highest
                      </Text>
                    </AppButton>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.35)',
    // alignItems: "center",
    // marginTop: 22,
    paddingHorizontal: 0,
  },
  modalView: {
    // margin: 20,
    backgroundColor: '#F3F3F3',
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    // padding: 35,
    paddingHorizontal: 10,
    // alignItems: "center",
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
});

export default SortByModal;
