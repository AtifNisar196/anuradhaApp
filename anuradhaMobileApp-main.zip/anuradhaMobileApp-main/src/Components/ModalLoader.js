import React, {Component} from 'react';
import {StyleSheet, View, Modal, ActivityIndicator, Text} from 'react-native';
import Colors from '../Themes/Colors';
import CommonStyles from '../CommonStyles';
class ModalLoader extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <View>
        <Modal
          back
          transparent={true}
          animationType={'none'}
          visible={this.props.visible}
          onRequestClose={() => {}}>
          <View style={styles.modalBackground}>
            <View
              style={{
                ...styles.activityIndicatorWrapper,
                paddingHorizontal: 10,
                paddingVertical: 15,
              }}>
              <View>
                <ActivityIndicator color={Colors.primary} size="small" />
              </View>

              <View style={{marginTop: 10}}>
                <Text
                  style={[
                    CommonStyles.fontMedium,
                    {color: Colors.primary, fontSize: 12},
                  ]}>
                  {'Processing'}
                </Text>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  modalBackground: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'space-around',
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  activityIndicatorWrapper: {
    backgroundColor: '#eeeeee',
    // padding: 25,

    borderRadius: 5,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
});

export default ModalLoader;
