import React from 'react';
import {
  TouchableOpacity,
  View,
  Text,
  Dimensions,
  ScrollView,
  Modal,
  StyleSheet,
} from 'react-native';
import Icon from 'react-native-vector-icons/AntDesign';
import CommonStyles from '../CommonStyles';
import Colors from '../Themes/Colors';

const DropdownPopup = ({
  modalShow,
  closeModal,
  setModalShow,
  selectedItem,
  title,
  placeHolder,
  renderItem,
  data,
  setValue,
}) => {
  const {height: screenHeight} = Dimensions.get('screen');

  function setPickerValue(item) {
    console.log("set va",item.name)
    setValue(item);
    closeModal();
  }

  return (
    <>
      <TouchableOpacity
        onPress={() => setModalShow()}
        style={{
          paddingLeft: 5,
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor:"#F3F3F3",
          // borderWidth: 1,
          borderColor: Colors.gray,
          borderRadius: 6,
          paddingVertical: 15,
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            alignContent: 'center',
          }}>
          <View style={{marginRight: 5, flex: 0.9}}>
            <Text
              style={[
                CommonStyles.fontMedium,
                CommonStyles.pl5,
                CommonStyles.textSizeSmallX,
                {color:!selectedItem ? "#2B2B2B" : "#2B2B2B"},
              ]}>
              {selectedItem || placeHolder}
            </Text>
          </View>
          <View style={{flex: 0.12}}>
            <Icon name="down" color={"#2B2B2B"} size={15} />
          </View>
        </View>
      </TouchableOpacity>
      <Modal
        visible={modalShow}
        transparent={true}
        onRequestClose={() => closeModal()}
        onDismiss={() => closeModal()}>
        <View
          activeOpacity={1}
          onPress={() => setModalShow(false)}
          style={{
            flex: 1,
            justifyContent: 'center',
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            padding: 20,
          }}>
          <View
            style={{
              maxHeight: screenHeight * 0.4,
              backgroundColor: '#fff',
              overflow: 'hidden',
              padding: 20,
              borderRadius: 5,
            }}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverageX,
                  CommonStyles.textColorPrimary,
                ]}>
                {selectedItem}
              </Text>
              <TouchableOpacity
                onPress={() => closeModal()}
                >
                <Icon name={'close'} size={15} color={Colors.primary} />
              </TouchableOpacity>
            </View>
            <View>
              <ScrollView style={{marginVertical: 10}}>
                {data &&
                  data.length > 0 &&
                  data?.map((item, index) => {
                    return (
                      <TouchableOpacity
                        key={index}
                        style={[CommonStyles.padding10]}
                        onPress={() => setPickerValue(item)}>
                        <View style={{borderBottomWidth: 0.5}}>
                          <Text
                            style={[
                              CommonStyles.fontMedium,
                              CommonStyles.textSizeAverage,
                              CommonStyles.textColorBlack,
                            ]}>
                            {item.name}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
              </ScrollView>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  radioText: {
    fontSize: 18,
    marginLeft: 10,
    color: '#000',
  },
  radioCircle: {
    height: 15,
    width: 15,
    borderRadius: 100,
    borderWidth: 2,
    borderColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedRb: {
    width: 7,
    height: 7,
    borderRadius: 50,
    backgroundColor: Colors.primary,
  },
});

export default DropdownPopup;
