import React, { memo } from "react";
import { StyleSheet, View } from "react-native";

const Notch = (props) => <View style={styles.root} {...props} />;

export default memo(Notch);

const styles = StyleSheet.create({
  root: {
    width: 5,
    height: 5,
    borderLeftColor: "transparent",
    borderRightColor: "transparent",
    borderTopColor: "#F5672D",
    borderLeftWidth: 4,
    borderRightWidth: 4,
    borderTopWidth: 8
  }
});
