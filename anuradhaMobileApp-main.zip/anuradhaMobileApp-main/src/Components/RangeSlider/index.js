import React, { useCallback, useState } from "react";
import RangeSliderRN from "rn-range-slider";
import { View, Text } from "react-native";

import Label from "./Label";
import Notch from "./Notch";
import Rail from "./Rail";
import RailSelected from "./RailSelected";
import Thumb from "./Thumb";

const RangeSlider = ({ from, to ,high,low,handleValueChange}) => {
  // const RangeSlider = () => {

  const renderThumb = useCallback(() => <Thumb />, []);
  const renderRail = useCallback(() => <Rail />, []);
  const renderRailSelected = useCallback(() => <RailSelected />, []);
  const renderLabel = useCallback((value) => <Label text={value} />, []);
  const renderNotch = useCallback(() => <Notch />, []);



  return (
    <>
     <RangeSliderRN
        // style={styles.slider}
        min={from}
        max={to}
        step={1}
        floatingLabel
        renderThumb={renderThumb}
        renderRail={renderRail}
        renderRailSelected={renderRailSelected}
        // renderLabel={renderLabel}
        // renderNotch={renderNotch}
        onValueChanged={handleValueChange}
      />
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginVertical: 10
        }}
      >
        <View>
        
          <Text
            style={[{ fontWeight: "bold" }, { fontSize: 12, color: "#F5672D" }]}
          >
            {low}Km
          </Text>
        </View>
        <View>
         
          <Text
            style={[{ fontWeight: "bold" }, { fontSize: 12, color: "#F5672D" }]}
          >
            {high}Km
          </Text>
        </View>
      </View>
     
    </>
  );
};

export default RangeSlider;
