import React, {useState} from 'react';
import {
  Alert,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  Pressable,
  View,
  Image,
} from 'react-native';
import CommonStyles from '../CommonStyles';
import {responsiveSpacing} from '../Utilities/Common';
import Colors from '../Themes/Colors';
import * as RootNavigation from '../Navigation/RootNavigation';
import images from '../assets/images';
import CancelReservationModal from './CancelReservationModal'
import AppButton from '../Components/AppButton';

const ComfimationModal = ({
  onRequestClose,
  setModalVisible,
  modalVisible,
  closeModal,
}) => {
  // const onCloseModal = () => {
  //   console.log('close');
  //   setModalVisible(false);
  // };

  const [modalVisibleClose, setModalVisibleClose] = useState(false);
  return (
    <View style={styles.centeredView}>
       <CancelReservationModal
          setModalVisible={modalVisibleClose}
          closeModal={() => setModalVisibleClose(false)}
          modalVisible={modalVisibleClose}
          // onRequestClose={!modalVisible}
        />
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => closeModal()}
        onDismiss={() => closeModal()}
        // onRequestClose={onCloseModal}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <View
              style={{
                flexDirection: 'row',
                // justifyContent: 'space-evenly',
                // alignItems: 'center',
                // paddingHorizontal: responsiveSpacing(20),
                marginVertical: responsiveSpacing(20),
              }}>
              <TouchableOpacity
                onPress={() => closeModal()}
                style={{
                  backgroundColor: '#F5672D',
                  padding: 10,
                  borderRadius: 10,
                }}>
                <Image
                  source={images.secclose}
                  //   style={{height: 40, width: 40}}
                />
              </TouchableOpacity>
            </View>
            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeMedium,
                  {
                    color: '#2B2B2B',
                    textAlign: 'center',
                    justifyContent: 'center',
                  },
                ]}>
                Thank you for using Zerve
              </Text>
            </View>
            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverage,
                  {
                    marginTop: 20,
                    color: '#2B2B2B',
                    textAlign: 'center',
                    justifyContent: 'center',
                  },
                ]}>
                Please wait for your modification to be processed
              </Text>
            </View>
            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeMedium,
                  {
                    color: Colors.primary,
                    textAlign: 'center',
                    justifyContent: 'center',
                    marginTop:50
                  },
                ]}>
                Status
              </Text>
            </View>
            <View
              style={{
                backgroundColor: Colors.primary,
                paddingVertical: 20,
                borderRadius: 20,
                marginHorizontal:80
              }}>
              <View style={{height: 100, width: 100, alignSelf: 'center'}}>
                <Image
                  source={images.pendloader}
                  style={{height: 100, width: 100}}
                />
              </View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeMedium,
                  {
                    color: '#fff',
                    textAlign: 'center',
                    justifyContent: 'center',
                  },
                ]}>
                Pending
              </Text>
            </View>
 
            <AppButton
              onPress={() => {
                closeModal(), setModalVisibleClose(true);
              }}
              containerStyles={{
                borderWidth: 0,
                borderRadius: 10,
                paddingHorizontal: responsiveSpacing(30),
                backgroundColor: '#F5672D',
                width: '100%',
                marginTop:50
              }}
              textStyle={[
                CommonStyles.fontMedium,
                CommonStyles.textSizeAverageX,
              ]}>
              <Text style={{color: '#fff', fontSize: 12}}>Cancel Reservation</Text>
            </AppButton>
            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeSmallM,
                  {
                    marginTop: 20,
                    color: '#6D6D6D',
                    textAlign: 'center',
                    justifyContent: 'center',
                  },
                ]}>
               If you cancel a reservation that is due in less than 1 hour, you will lose some points and trust rating.
              </Text>
            </View>

            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeSmallM,
                  {
                    marginTop: 30,
                    color: '#2B2B2B',
                    textAlign: 'center',
                    justifyContent: 'center',
                    paddingBottom:20
                  },
                ]}>
              You may close this screen and you will be notified through sms regarding the status of the reservation, alternatively you can view the status from your user screen.
              </Text>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.35)',
    // alignItems: "center",
    // marginTop: 22,
    paddingHorizontal: 20,
  },
  modalView: {
    // margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    // padding: 35,
    paddingHorizontal: 10,
    // alignItems: "center",
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
});

export default ComfimationModal;
