/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React from 'react';
import { StyleSheet, TextInput, View, Keyboard, Button, Text, TouchableOpacity, Image } from 'react-native';
import Colors from '../Themes/Colors';
import CommonStyles from '../CommonStyles';
import Icons from 'react-native-vector-icons/Ionicons';
import { navigate, goBack } from '../Navigation/RootNavigation';
import { Feather, Entypo } from '/re';
const NavigationBar = ({
  rightImage,
  leftImage,
  rightHandler,
  leftHandler,
  rightHandler2,
  rightImage2,
  clicked, searchPhrase, setSearchPhrase, setCLicked,
  title,
}) => {
  return (
    <View
      style={{
        flexDirection: 'row',
        paddingVertical: 15,
        paddingHorizontal: 0,
      }}>
      <View style={{ flex: 1 }}>
        {leftHandler && (
          <View style={{ flexDirection: 'row' }}>
            <TouchableOpacity
              onPress={goBack}
              style={{
                // backgroundColor: Colors.primary,
                padding: 10,
                justifyContent: 'center',
                alignItems: 'center',
                borderRadius: 5,
              }}>
              <View style={{ height: 40, width: 35 }}>
                <Image
                  style={{
                    flex: 1,
                    height: undefined,
                    width: undefined,
                    resizeMode: 'contain',
                  }}
                  source={leftImage}
                />
              </View>
            </TouchableOpacity>
          </View>
        )}
      </View>

      <View
        style={{
          justifyContent: 'center',
          // alignItems: 'flex-start',
          flex: 8,
          marginLeft: 15,
        }}>
        <View
          style={
            clicked
              ? styles.searchBar__clicked
              : styles.searchBar__unclicked
          }
        >
          {/* search Icon */}
          <Icons
            name="search"
            size={15}
            color="#838383"
            style={{ marginLeft: 1 }}
          />
          {/* Input field */}
          <TextInput
            style={styles.input}
            placeholder="Search"
            value={searchPhrase}
            onChangeText={setSearchPhrase}

            onFocus={() => {
              setClicked(true);
            }}
          />
          {/* cross Icon, depending on whether the search bar is clicked or not */}
          {clicked && (
            <Icons name="cross" size={15} color="#838383" style={{ padding: 1 }} onPress={() => {
              setSearchPhrase('');
            }} />
          )}
        </View>
        {/* cancel button, depending on whether the search bar is clicked or not */}
        {clicked && (
          <View>
            <Button
              title="Cancel"
              onPress={() => {
                Keyboard.dismiss();
                setClicked(false);
              }}
            />
          </View>
        )}
      </View>
      <View style={{ flex: 1, flexDirection: 'row-reverse' }}>
        {rightHandler && (
          <View style={{ flexDirection: 'row' }}>
            <TouchableOpacity
              onPress={rightHandler}
              style={{
                // backgroundColor: Colors.primary,
                // padding: 10,
                paddingRight: 10,
                borderRadius: 5,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <View style={{ height: 40, width: 35 }}>
                <Image
                  style={{
                    flex: 1,
                    height: undefined,
                    width: undefined,
                    resizeMode: 'center',
                  }}
                  source={rightImage2}
                />
              </View>
            </TouchableOpacity>
          </View>
        )}
        {rightHandler2 && (
          <View style={{ flexDirection: 'row' }}>
            <TouchableOpacity
              onPress={rightHandler2}
              style={{
                // backgroundColor: Colors.primary,

                padding: 10,
                borderRadius: 5,
                justifyContent: 'center',
                alignItems: 'center',
              }}>

              <View style={{ height: 40, width: 35 }}>
                <Image
                  style={{
                    flex: 1,
                    height: undefined,
                    width: undefined,
                    resizeMode: 'center',
                  }}
                  source={rightImage}
                />
              </View>
            </TouchableOpacity>
          </View>
        )}

      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 15,
    // justifyContent: 'flex-start',
    // alignItems: 'center',
    // flexDirection: 'row',
    width: '80%',

  },
  searchBar__unclicked: {
    paddingHorizontal: 10,
    flexDirection: 'row',
    width: '80%',
    backgroundColor: '#fff',
    borderRadius: 30,
    alignItems: 'center',
  },
  searchBar__clicked: {
    paddingHorizontal: 10,
    flexDirection: 'row',
    width: '70%',
    backgroundColor: '#fff',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'space-evenly',
  },
  input: {
    color: '#838383',
    fontSize: 20,
    width: '70%',
    fontSize: 15,
  },
});
export default NavigationBar;
