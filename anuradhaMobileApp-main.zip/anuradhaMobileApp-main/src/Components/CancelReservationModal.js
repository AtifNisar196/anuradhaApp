import React, {useState} from 'react';
import {
  Alert,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  Pressable,
  View,
  FlatList,
  Image,
} from 'react-native';
import CommonStyles from '../CommonStyles';
import {responsiveSpacing} from '../Utilities/Common';
import Colors from '../Themes/Colors';
import * as RootNavigation from '../Navigation/RootNavigation';
import images from '../assets/images';
import CancelationModal from './CancelationModal';
import AppButton from '../Components/AppButton';
import moment from 'moment';
import {widthPercentageToDP} from 'react-native-responsive-screen';

const CancelReservationModal = ({
  onRequestClose,
  setModalVisible,
  modalVisible,
  closeModal,
  onPress,
  data,
}) => {
  // const onCloseModal = () => {
  //   console.log('close');
  //   setModalVisible(false);
  // };

  const tableArr = [
    {
      day: 'M',
      date: '01',
      time: '13:00',
      isSelected: true,
      hasReserved: false,
    },
    {
      day: 'T',
      date: '02',
      time: '14:00',
      isSelected: true,
      hasReserved: false,
    },
    {
      day: 'W',
      date: '03',
      time: '05:00',
      isSelected: true,
      hasReserved: false,
    },
  ];

  // console.log(data, 'sssss modal');
  const [modalVisibleClose, setModalVisibleClose] = useState(false);
  return (
    <View style={styles.centeredView}>
      <CancelationModal
        setModalVisible={modalVisibleClose}
        closeModal={() => setModalVisibleClose(false)}
        modalVisible={modalVisibleClose}
        // onRequestClose={!modalVisible}
      />
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => closeModal()}
        onDismiss={() => closeModal()}
        // onRequestClose={onCloseModal}ss
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <View
              style={{
                flexDirection: 'row',
                marginTop: 40,
              }}>
              <TouchableOpacity
                onPress={() => closeModal()}
                style={{
                  backgroundColor: '#F5672D',
                  padding: 10,
                  borderRadius: 10,
                }}>
                <Image
                  source={images.secclose}
                  //   style={{height: 40, width: 40}}
                />
              </TouchableOpacity>
            </View>
            <View
              style={{
                borderRadius: 20,
                paddingHorizontal: 10,
                paddingVertical: 20,
              }}>
              <View>
                <Text
                  style={[
                    CommonStyles.fontBold,
                    CommonStyles.textSizeMedium,
                    {
                      color: '#2B2B2B',
                      textAlign: 'center',
                      justifyContent: 'center',
                    },
                  ]}>
                  Are you Sure you wish to cancel?
                </Text>
              </View>
              <View>
                <Text
                  style={[
                    CommonStyles.fontRegular,
                    CommonStyles.textSizeAverageX,
                    {
                      color: '#2B2B2B',
                      textAlign: 'center',
                      marginTop: 30,
                      // textTransform: 'uppercase',
                    },
                  ]}>
                  Reservation For
                </Text>
              </View>
              <View>
                <View
                  style={{
                    width: 120,
                    height: 120,
                    alignItems: 'center',
                    justifyContent: 'center',
                    alignSelf: 'center',
                    marginTop: responsiveSpacing(10),
                  }}>
                  <Image
                    style={{flex: 1, width: 150, height: 150}}
                    source={images.bussinesspro}
                    resizeMode="contain"
                  />
                </View>
                <View>
                  <Text
                    style={[
                      CommonStyles.fontRegular,
                      CommonStyles.textSizeAverageX,
                      {
                        color: '#2B2B2B',
                        textAlign: 'center',
                        marginTop: 10,
                        // textTransform: 'uppercase',
                      },
                    ]}>
                    {data?.data?.businessId?.name}
                  </Text>
                </View>
              </View>

              <View
                style={{
                  marginVertical: responsiveSpacing(20),
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  //   flex: 1,
                  paddingHorizontal: responsiveSpacing(0),
                }}>
                <View style={{alignItems: 'center'}}>
                  <Text
                    style={[
                      CommonStyles.fontMedium,
                      {
                        color: Colors.fontSecondary,
                      },
                    ]}>
                    Date
                  </Text>

                  <View
                    style={{
                      backgroundColor: Colors.primary,
                      width: widthPercentageToDP('21'),
                      paddingVertical: responsiveSpacing(3),
                      borderRadius: 10,
                      alignItems: 'center',
                    }}>
                    <Text
                      style={[
                        CommonStyles.fontMedium,
                        {
                          color: '#fff',
                        },
                      ]}>
                      {moment(data?.data?.reservationDate, 'YYYY/MM/DD').format(
                        'D/MM',
                      )}
                    </Text>
                  </View>
                </View>
                <View style={{alignItems: 'center'}}>
                  <Text
                    style={[
                      CommonStyles.fontMedium,
                      {
                        color: Colors.fontSecondary,
                      },
                    ]}>
                    Time
                  </Text>

                  <View
                    style={{
                      backgroundColor: Colors.primary,
                      width: widthPercentageToDP('21'),
                      paddingVertical: responsiveSpacing(3),
                      borderRadius: 10,
                      alignItems: 'center',
                    }}>
                    <Text
                      style={[
                        CommonStyles.fontMedium,
                        {
                          color: '#fff',
                        },
                      ]}>
                      {moment(data?.data?.reservationDate, 'HHmm').format(
                        'HH:mm',
                      )}
                    </Text>
                  </View>
                </View>
                <View style={{alignItems: 'center'}}>
                  <Text
                    style={[
                      CommonStyles.fontMedium,
                      {
                        color: Colors.fontSecondary,
                      },
                    ]}>
                    Seats
                  </Text>

                  <View
                    style={{
                      backgroundColor: Colors.primary,
                      width: widthPercentageToDP('21'),
                      paddingVertical: responsiveSpacing(3),
                      borderRadius: 10,
                      alignItems: 'center',
                    }}>
                    <Text
                      style={[
                        CommonStyles.fontMedium,
                        {
                          color: '#fff',
                        },
                      ]}>
                      {data?.data?.userRequest?.noOfSeats}
                    </Text>
                  </View>
                </View>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginTop: 20,
                  marginBottom: 15,
                }}>
                <Text
                  style={[
                    CommonStyles.fontMedium,
                    {color: '#2B2B2B'},
                    CommonStyles.textSizeAverageX,
                  ]}>
                  Location
                </Text>
                <TouchableOpacity>
                  <Text
                    style={[
                      CommonStyles.fontMedium,
                      {color: Colors.primary},
                      CommonStyles.textSizeAverageX,
                    ]}>
                    View on Maps
                  </Text>
                </TouchableOpacity>
              </View>
              <View
                style={{
                  // backgroundColor: '#F3F3F3',
                  // paddingVertical: 20,
                  // paddingHorizontal: 15,
                  borderRadius: 10,
                }}>
                <Text
                  style={[
                    {color: '#6D6D6D'},
                    CommonStyles.textSizeSmallM,
                    CommonStyles.fontMedium,
                  ]}>
                  521 Leoforou Street - Deryneia, 5380
                </Text>
              </View>
            </View>

            <View
              style={{
                marginVertical: responsiveSpacing(20),
                // flex: 1,
                paddingTop: 0,
              }}>
              <AppButton
                onPress={() => {
                  closeModal(), setModalVisibleClose(true);
                  onPress();
                }}
                containerStyles={{
                  //   flex: 1,
                  borderWidth: 0,
                  //   width: '100%',
                  backgroundColor: Colors.primary,
                  paddingVertical: responsiveSpacing(15),
                }}
                textStyle={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeSmallX,
                ]}>
                <Text style={{color: '#fff'}}>Yes Cancel Reservation</Text>
              </AppButton>
            </View>
            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeSmallM,
                  {
                    marginTop: 20,
                    color: '#6D6D6D',
                    textAlign: 'center',
                    justifyContent: 'center',
                    marginBottom: 30,
                  },
                ]}>
                If you cancel a reservation that is due in less than 1 hour, you
                will lose some points and trust rating.
              </Text>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.35)',
    // alignItems: "center",
    // marginTop: 22,
    paddingHorizontal: 20,
  },
  modalView: {
    // margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    // padding: 35,
    paddingHorizontal: 10,
    // alignItems: "center",
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
});

export default CancelReservationModal;
