import React from 'react';
import {View, Image, Dimensions, Text, TouchableOpacity} from 'react-native';
import CommonStyles from '../CommonStyles';
import Colors from '../Themes/Colors';
import { navigate,goBack } from '../Navigation/RootNavigation';

const {height, width} = Dimensions.get('window');
const FallbackComponent = props => {
  console.log("propsss",props)
  return (
    <View
      style={{
        flex: 1,
        aligSelf: 'center',
        alignContent: 'center',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
      <View
        style={{
          height: 100,
          width: 100,
          justifyContent: 'center',
          alignContent: 'center',
          alignSelf: 'center',
        }}>
        <Image
          source={props.imageUrl}
          style={{flex: 1, height: undefined, width: undefined}}
          resizeMode="contain"
        />
      </View>
      <View style={{paddingHorizontal: 30, marginVertical: 20}}>
        <Text
          style={[
            CommonStyles.textColorBlack,
            CommonStyles.textSizeAverageX,
            CommonStyles.fontMedium,
            {textAlign: 'center'},
          ]}>
          {props.text}
        </Text>
      </View>
      <TouchableOpacity onPress={() => props.navigate()}  style={{backgroundColor:Colors.primary,paddingHorizontal:10,paddingVertical:10,borderRadius:10}}>
        <Text style={{color:"#fff"}}>Go Back</Text>
      </TouchableOpacity>
    </View>
  );
};

export default FallbackComponent;
