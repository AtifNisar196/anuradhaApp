import React, {useState} from 'react';
import {
  Alert,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  Pressable,
  View,
  Image,
} from 'react-native';
import CommonStyles from '../CommonStyles';
import {responsiveSpacing} from '../Utilities/Common';
import Colors from '../Themes/Colors';
import * as RootNavigation from '../Navigation/RootNavigation';
import images from '../assets/images';
import AppButton from '../Components/AppButton';

const CancelationModal = ({
  onRequestClose,
  setModalVisible,
  modalVisible,
  closeModal,
}) => {
  // const onCloseModal = () => {
  //   console.log('close');
  //   setModalVisible(false);
  // };

  const [modalVisibleClose, setModalVisibleClose] = useState(false);
  return (
    <View style={styles.centeredView}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => closeModal()}
        onDismiss={() => closeModal()}
        // onRequestClose={onCloseModal}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <View
              style={{
                flexDirection: 'row',
                // justifyContent: 'space-evenly',
                // alignItems: 'center',
                // paddingHorizontal: responsiveSpacing(20),
                marginVertical: responsiveSpacing(20),
              }}>
              <TouchableOpacity
                onPress={() => closeModal()}
                style={{
                  backgroundColor: '#F5672D',
                  padding: 10,
                  borderRadius: 10,
                }}>
                <Image
                  source={images.secclose}
                  //   style={{height: 40, width: 40}}
                />
              </TouchableOpacity>
            </View>
            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeMedium,
                  {
                    color: '#2B2B2B',
                    textAlign: 'center',
                    justifyContent: 'center',
                  },
                ]}>
                Cancelation Completed
              </Text>
            </View>

            <View
              style={
                {
                  // backgroundColor: Colors.primary,
                  // paddingVertical: 20,
                  // borderRadius: 20,
                  // marginHorizontal: 80,
                }
              }>
              <View
                style={{
                  height: 100,
                  width: 100,
                  alignSelf: 'center',
                  marginTop: 50,
                }}>
                <Image
                  source={images.heartbrok}
                  style={{height: 100, width: 100}}
                />
              </View>
              <View>
                <Text
                  style={[
                    CommonStyles.fontMedium,
                    CommonStyles.textSizeBig,
                    {
                      color: Colors.primary,
                      textAlign: 'center',
                      justifyContent: 'center',
                      marginTop: 50,
                    },
                  ]}>
                  -200 Points
                </Text>
                <Text
                  style={[
                    CommonStyles.fontMedium,
                    CommonStyles.textSizeBig,
                    {
                      color: Colors.primary,
                      textAlign: 'center',
                      justifyContent: 'center',
                      marginVertical: 50,
                    },
                  ]}>
                  -10% Trust Rating
                </Text>
              </View>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.35)',
    // alignItems: "center",
    // marginTop: 22,
    paddingHorizontal: 20,
  },
  modalView: {
    // margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    // padding: 35,
    paddingHorizontal: 10,
    // alignItems: "center",
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
});

export default CancelationModal;
