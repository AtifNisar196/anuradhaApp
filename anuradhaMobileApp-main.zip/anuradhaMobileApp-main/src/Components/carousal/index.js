/* eslint-disable prettier/prettier */
import React, { useState } from 'react';
import {
  View,
  Image,
  Dimensions,
  FlatList,
  StyleSheet,
  ViewPagerAndroid,
} from 'react-native';
import images from '../../assets/images';

const { width } = Dimensions.get('window');

const data = [
  { id: '1', uri: images.Banner },
  { id: '2', uri: images.Banner },
  { id: '3', uri: images.Banner },
];

const BannerSlider = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const viewabilityConfig = {
    itemVisiblePercentThreshold: 50,
  };

  const onViewableItemsChanged = ({ viewableItems }) => {
    if (viewableItems.length > 0) {
      setCurrentIndex(viewableItems[0].index);
    }
  };

  return (
    <View>
      <FlatList
        data={data}
        keyExtractor={item => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={styles.slide}>
            <Image source={item.uri} style={styles.image} />
          </View>
        )}
        onViewableItemsChanged={onViewableItemsChanged}
        viewabilityConfig={viewabilityConfig}
      />
      <View style={styles.pagination}>
        {data.map((_, index) => (
          <View
            key={index}
            style={[styles.dot, { opacity: currentIndex === index ? 1 : 0.5 }]}
          />
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  slide: {
    width,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width,
    height: 200,
    resizeMode: 'center',
  },
  pagination: {
    flexDirection: 'row',
    position: 'absolute',
    bottom: 10,
    alignSelf: 'center',
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
    margin: 5,
  },
});

export default BannerSlider;
