import React, {useState} from 'react';
import {
  Alert,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  Pressable,
  View,
  Image,
  TextInput,
} from 'react-native';
import CommonStyles from '../CommonStyles';
import {responsiveSpacing} from '../Utilities/Common';
import Colors from '../Themes/Colors';
import * as RootNavigation from '../Navigation/RootNavigation';
import images from '../assets/images';
import CancelReservationModal from './CancelReservationModal';
import AppButton from './AppButton';
import DateTimePicker from '@react-native-community/datetimepicker';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import moment from 'moment';

const ModifySeatsModal = ({
  setModalVisible,
  modalVisible,
  closeModal,
  func,
}) => {
  const [seats, setSeats] = useState(null);

  return (
    <View style={styles.centeredView}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => closeModal()}
        onDismiss={() => closeModal()}
        // onRequestClose={onCloseModal}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <View
              style={{
                flexDirection: 'row',
                marginVertical: responsiveSpacing(20),
              }}>
              <TouchableOpacity
                onPress={() => closeModal()}
                style={{
                  backgroundColor: '#F5672D',
                  padding: 10,
                  borderRadius: 10,
                }}>
                <Image
                  source={images.secclose}
                  //   style={{height: 40, width: 40}}
                />
              </TouchableOpacity>
            </View>
            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeMedium,
                  {
                    color: '#2B2B2B',
                    textAlign: 'center',
                    justifyContent: 'center',
                  },
                ]}>
                Thank you for using Zerve
              </Text>
            </View>

            <View
              style={{
                flexDirection: 'row',
                paddingVertical: heightPercentageToDP('2'),
                justifyContent: 'center',
                // backgroundColor: 'red',
              }}>
              <View style={styles.commonView}>
                <Text>Seats</Text>
                <TextInput
                  // keyboardType='numeric'
                  placeholderTextColor={'white'}
                  placeholder="Select Seats"
                  style={styles.touchableBtn}
                  value={seats}
                  onChangeText={text => {
                    setSeats(text);
                  }}
                />
              </View>
            </View>

            <AppButton
              onPress={() => {
                func(seats);
                closeModal();
              }}
              containerStyles={{
                borderWidth: 0,
                borderRadius: 10,
                paddingHorizontal: responsiveSpacing(30),
                backgroundColor: '#F5672D',
                width: '100%',
                marginTop: 15,
              }}
              textStyle={[
                CommonStyles.fontMedium,
                CommonStyles.textSizeAverageX,
              ]}>
              <Text style={{color: '#fff', fontSize: 12}}>Modify Seats</Text>
            </AppButton>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.35)',
    // alignItems: "center",
    // marginTop: 22,
    paddingHorizontal: 20,
  },
  modalView: {
    backgroundColor: 'white',
    borderRadius: 20,
    paddingHorizontal: 10,
    shadowColor: '#000',
    // flex: 0.35,
    paddingBottom: 15,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
  input: {
    // backgroundColor:
  },
  datePicker: {
    justifyContent: 'center',
    alignItems: 'flex-start',
    width: 320,
    height: 260,
    display: 'flex',
  },
  touchableBtn: {
    backgroundColor: 'gray',
    paddingVertical: responsiveSpacing(3),
    width: widthPercentageToDP('23%'),
    alignItems: 'center',
    height: heightPercentageToDP('4'),
    justifyContent: 'center',
    borderRadius: 6,
    color: 'white',
  },
  touchableText: {
    color: 'white',
  },
  commonView: {
    alignItems: 'center',
  },
});

export default ModifySeatsModal;
