import React, {useState} from 'react';
import {
  Alert,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  Pressable,
  View,
  Image,
} from 'react-native';
import CommonStyles from '../CommonStyles';
import {responsiveSpacing} from '../Utilities/Common';
import Colors from '../Themes/Colors';
import * as RootNavigation from '../Navigation/RootNavigation';
import images from '../assets/images';
import AppButton from '../Components/AppButton';

const GameModal = ({
  onRequestClose,
  setModalVisible,
  modalVisible,
  closeModal,
}) => {
  // const onCloseModal = () => {
  //   console.log('close');
  //   setModalVisible(false);
  // };

  const [modalVisibleClose, setModalVisibleClose] = useState(false);
  return (
    <View style={styles.centeredView}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => closeModal()}
        onDismiss={() => closeModal()}
        // onRequestClose={onCloseModal}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <View
              style={{
                flexDirection: 'row',
                // justifyContent: 'space-evenly',
                // alignItems: 'center',
                // paddingHorizontal: responsiveSpacing(20),
                marginVertical: responsiveSpacing(20),
              }}>
              <TouchableOpacity
                onPress={() => closeModal()}
                style={{
                  backgroundColor: '#F5672D',
                  padding: 10,
                  borderRadius: 10,
                }}>
                <Image
                  source={images.secclose}
                  //   style={{height: 40, width: 40}}
                />
              </TouchableOpacity>
            </View>
            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeMedium,
                  {
                    color: '#2B2B2B',
                    textAlign: 'center',
                    justifyContent: 'center',
                  },
                ]}>
                Thank you for using Zerve
              </Text>
            </View>
            <View>
              <Text
                style={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverage,
                  {
                    marginTop: 20,
                    color: '#2B2B2B',
                    textAlign: 'center',
                    justifyContent: 'center',
                    marginBottom: 40,
                  },
                ]}>
                Please wait for your modification to be processed
              </Text>
            </View>
            <View></View>
            <View
              style={{
                marginLeft: 5,
                // backgroundColor: Colors.primary,
                // paddingVertical: 20,
                // borderRadius: 20,
                // marginHorizontal:80
              }}>
              <View>
                <Image
                  source={images.gamepopup}
                  // style={{height: 100, width: 100}}
                />
              </View>
        
            </View>
            <View style={{flexDirection:"row",justifyContent:"space-between",marginTop:10,paddingRight:10}}>
              <View style={{width:"20%"}}>
              <Text style={{color:Colors.primary,textAlign:"center"}}>A group of friends</Text>
              </View>
              <View>
              <Text  style={{color:Colors.primary,textAlign:"center"}}>Restaurant</Text>
              </View>
              <View>
              <Text  style={{color:Colors.primary,textAlign:"center"}}>Dinner</Text>
              </View>
              <View>
              <Text  style={{color:Colors.primary,textAlign:"center"}}>Fast Food</Text>
              </View>
            </View>

            <AppButton
              onPress={() => {
                closeModal(), RootNavigation.navigate('Home');
              }}
              containerStyles={{
                borderRadius: 10,
                paddingHorizontal: responsiveSpacing(30),
                backgroundColor: '#fff',
                width: '100%',
                marginTop: 50,
                borderWidth: 1,
                borderColor: '#3f3f3f',
              }}
              textStyle={[
                CommonStyles.fontMedium,
                CommonStyles.textSizeAverageX,
              ]}>
              <Text style={{color: '#000', fontSize: 12}}>
                Restart Questions
              </Text>
            </AppButton>

            <AppButton
              onPress={() => {
                closeModal(), RootNavigation.navigate('Home');
              }}
              containerStyles={{
                borderWidth: 0,
                borderRadius: 10,
                paddingHorizontal: responsiveSpacing(30),
                backgroundColor: '#F5672D',
                width: '100%',
                marginTop: 20,
                marginBottom: 50,
              }}
              textStyle={[
                CommonStyles.fontMedium,
                CommonStyles.textSizeAverageX,
              ]}>
              <Text style={{color: '#fff', fontSize: 12}}>
                Cancel Reservation
              </Text>
            </AppButton>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.35)',
    // alignItems: "center",
    // marginTop: 22,
    paddingHorizontal: 20,
  },
  modalView: {
    // margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    // padding: 35,
    paddingHorizontal: 10,
    // alignItems: "center",
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
});

export default GameModal;
