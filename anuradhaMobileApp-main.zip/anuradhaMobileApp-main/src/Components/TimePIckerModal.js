import React, { useState } from 'react';
import {
  TouchableOpacity,
  View,
  Text,
  Dimensions,
  Image,
  ScrollView,
  Modal,
  StyleSheet,
} from 'react-native';
import Icon from 'react-native-vector-icons/AntDesign';
import CommonStyles from '../CommonStyles';
import moment from 'moment';
import { responsiveSpacing } from '../Utilities/Common';
import Colors from '../Themes/Colors';
import AppButton from '../Components/AppButton';
import images from '../assets/images';

import DateTimePicker from '@react-native-community/datetimepicker';

const TimePIckerModal = ({
  modalShow,
  closeModal,
  setModalShow,
  selectedItem,
  title,
  placeHolder,
  renderItem,
  data,
  setValue,
}) => {
  const { height: screenHeight } = Dimensions.get('screen');

  const [date, setDate] = useState(new Date());
  const [enddate, setendDate] = useState(new Date());
  const [mode, setMode] = useState('date');
  const [show, setShow] = useState(false);
  const [startTime, setStartTime] = useState();

  const [endTime, setEndTime] = useState();
  const onChangeStart = (event, selectedDate) => {
    console.log('Slecttime', selectedDate);

    setStartTime(selectedDate);
    const currentDate = selectedDate || data;
    setShow(Platform.OS === 'ios');
    setDate(currentDate);
  };


  const onChangeEnd = (event, selectedDate) => {
    console.log('Slecttime', selectedDate);

    setEndTime(selectedDate);
    const currentDate = selectedDate || enddate;
    setShow(Platform.OS === 'ios');
    setendDate(currentDate);
  };


  console.log('uoodates', startTime);
  console.log('endTime', endTime);
  const showMode = currentMode => {
    setShow(true);
    setMode(currentMode);
  };

  const showTimepicker = () => {
    showMode('time');
  };

  return (
    <>
      <TouchableOpacity
        onPress={() => setModalShow()}
        style={{
          paddingLeft: 5,
          flexDirection: 'row',
          width: '60%',
          alignItems: 'flex-end',
          backgroundColor: '#fff',
          // borderWidth: 1,
          borderColor: Colors.gray,
          borderRadius: 6,
          paddingVertical: 15,
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            alignContent: 'center',
            backgroundColor: '#ffffff',
          }}>
          <View style={{ marginRight: 5, flex: 0.9 }}>
            <Text
              style={[
                CommonStyles.fontMedium,
                CommonStyles.pl5,
                CommonStyles.textSizeAverageX,
                { color: !selectedItem ? '#F5672D' : '#F5672D' },
              ]}>
              {placeHolder}
            </Text>
          </View>
          {/* <View style={{flex: 0.12}}>
            <Icon name="down" color={Colors.primary} size={15} />
          </View> */}
        </View>
      </TouchableOpacity>
      <Modal
        visible={modalShow}
        transparent={true}
        onRequestClose={() => closeModal()}
        onDismiss={() => closeModal()}>
        <View
          activeOpacity={1}
          onPress={() => setModalShow(false)}
          style={{
            flex: 1,
            justifyContent: 'center',
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            padding: 20,
          }}>
          <View
            style={{
              maxHeight: screenHeight * 0.6,
              backgroundColor: '#fff',
              overflow: 'hidden',
              padding: 20,
              borderRadius: 5,
            }}>
            <View
              style={{
                flexDirection: 'row',
                // justifyContent: 'space-evenly',
                alignItems: 'center',
                // paddingHorizontal: responsiveSpacing(20),
                marginVertical: responsiveSpacing(20),
              }}>
              <TouchableOpacity
                onPress={() => closeModal()}
                style={{
                  backgroundColor: '#F5672D',
                  padding: 10,
                  borderRadius: 10,
                }}>
                <Image
                  source={images.secclose}
                //   style={{height: 40, width: 40}}
                />
              </TouchableOpacity>
              <View
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  flex: 5,
                }}>
                <Text
                  style={[
                    CommonStyles.fontMedium,
                    CommonStyles.textSizeBig,
                    {
                      color: '#2B2B2B',
                      textAlign: 'center',
                      justifyContent: 'center',
                    },
                  ]}>
                  Set Time
                </Text>
              </View>
            </View>

            <View>
              <TouchableOpacity
                onPress={showTimepicker}
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  borderWidth: 1,
                  borderColor: '#F3F3F3',
                  marginTop: 20,
                  borderRadius: 20,
                  paddingVertical: 12,
                  paddingHorizontal: 15,
                }}>
                <Text
                  style={[
                    CommonStyles.fontMedium,
                    CommonStyles.pl5,
                    CommonStyles.textSizeAverageX,
                    { color: !selectedItem ? '#F5672D' : '#F5672D' },
                  ]}>
                  {moment(startTime).format('hh:mma') || placeHolder}

                </Text>
                <Icon name="clockcircleo" color={'#6D6D6D'} size={25} />
              </TouchableOpacity>

              {show && (
                <DateTimePicker
                  testID="dateTimePicker"
                  timeZoneOffsetInMinutes={0}
                  value={date}
                  mode={mode}
                  is24Hour={true}
                  display="default"
                  onChange={onChangeStart}
                />
              )}
              {/* <Text>{startTime || 'Start Time'}</Text> */}
            </View>

            <View>
              <TouchableOpacity
                onPress={showTimepicker}
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  borderWidth: 1,
                  borderColor: '#F3F3F3',
                  marginTop: 20,
                  borderRadius: 20,
                  paddingVertical: 12,
                  paddingHorizontal: 15,
                }}>
                <Text
                  style={[
                    CommonStyles.fontMedium,
                    CommonStyles.pl5,
                    CommonStyles.textSizeAverageX,
                    { color: !selectedItem ? '#F5672D' : '#F5672D' },
                  ]}>
                  {moment(endTime).format('hh:mma') || placeHolder}
                </Text>
                <Icon name="clockcircleo" color={'#6D6D6D'} size={25} />
              </TouchableOpacity>

              {show && (
                <DateTimePicker
                  testID="dateTimePicker"
                  timeZoneOffsetInMinutes={0}
                  value={enddate}
                  mode={mode}
                  is24Hour={true}
                  display="default"
                  onChange={onChangeEnd}
                />
              )}
              {/* <Text>{startTime || 'Start Time'}</Text> */}
            </View>
            <View
              style={{
                marginVertical: responsiveSpacing(10),
                flexDirection: 'column',
                justifyContent: 'space-between',
                paddingHorizontal: 0,
              }}>
              <AppButton
                // onPress={() => {
                //   props.navigation.navigate('Arrivals');
                // }}
                containerStyles={{
                  borderWidth: 0,
                  borderRadius: 10,
                  marginVertical: 30,
                  paddingHorizontal: responsiveSpacing(30),
                  backgroundColor: '#F5672D',
                  width: '100%',
                }}
                textStyle={[
                  CommonStyles.fontMedium,
                  CommonStyles.textSizeAverageX,
                ]}>
                <Text style={{ color: '#fff', fontSize: 18 }}>Submit</Text>
              </AppButton>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  radioText: {
    fontSize: 18,
    marginLeft: 10,
    color: '#000',
  },
  radioCircle: {
    height: 15,
    width: 15,
    borderRadius: 100,
    borderWidth: 2,
    borderColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedRb: {
    width: 7,
    height: 7,
    borderRadius: 50,
    backgroundColor: Colors.primary,
  },
});

export default TimePIckerModal;
