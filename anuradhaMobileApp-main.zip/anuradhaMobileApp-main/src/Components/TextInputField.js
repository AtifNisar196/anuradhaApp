/* eslint-disable prettier/prettier */
import React from 'react';
import { Text, TextInput, StyleSheet, View } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import CommonStyles from '../CommonStyles';
import Colors from '../Themes/Colors';

const TextInputField = ({
  field: { name, onBlur, onChange, value },
  form: { errors, touched, setFieldTouched },
  inputStyle,
  iconName,
  isSecure,
  isDisbale,
  maxLength,
  ...inputProps
}) => {
  const hasError = errors[name] && touched[name];
  return (
    <>
      <View>
        <View style={styles.textInputcontainer}>
          <TextInput
            maxLength={maxLength}
            editable={isDisbale}
            placeholderTextColor={'#838383'}
            secureTextEntry={isSecure}
            style={[
              styles.textInput,
              inputStyle,
              hasError && styles.errorInput,
            ]}
            value={value}
            onChangeText={text => {
              if (name === 'email') {
                let emailText = text.trim();
                onChange(name)(emailText);
              } else {
                onChange(name)(text);
              }
            }}
            onBlur={text => {
              setFieldTouched(name);
              onBlur(name);
            }}
            {...inputProps}
          />
          <View style={{ alignItems: 'flex-start', paddingRight: 10 }}>
            {iconName && <Icon name={iconName} size={20} color="#838383" />}
          </View>
        </View>
        {hasError && <Text style={styles.errorText}>{errors[name]}</Text>}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  textInputcontainer: {
    paddingLeft: 5,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: '#838383',
    height: 60,
    borderRadius: 10,
  },

  textInput: {
    ...CommonStyles.fontRegular,
    backgroundColor: 'transparent',
    paddingVertical: 8,
    paddingHorizontal: 10,
    fontSize: 16,
    flex: 1,
    color: '#838383',
  },
  errorText: {
    fontSize: 10,
    color: 'red',
    paddingHorizontal: 5,
    paddingVertical: 5,
  },
  errorInput: {
    borderColor: 'red',
    backgroundColor: Colors.white,
  },
});

export default TextInputField;
