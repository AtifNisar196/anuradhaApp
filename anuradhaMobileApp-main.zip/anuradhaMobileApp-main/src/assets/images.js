export default {
  logo: require('./images/ImageBoard.png'), // getting used
  background: require('./images/background.png'), // getting used
  selectedCheck: require('./images/selectcheck.png'), // getting used
  unselectedCheck: require('./images/unselectcheck.png'), // getting used
  threedots: require('./images/Three-dots.png'), // getting used
  threedotsnext: require('./images/Three-dots-next.png'), // getting used
  ArrowButton: require('./images/Arrow-Button.png'), // getting used
  Banner: require('./images/Banner.png'), // getting used
  HomeIcon: require('./images/Home.png'), // getting used
  Message: require('./images/Message.png'), // getting used
  FavIcon: require('./images/Fav.png'), // getting used
  Account: require('./images/Account.png'),
  RoundImage: require('./images/RoundImage.png'),
  productImage: require('./images/product1.png'),
  productCategory: require('./images/productCategory.png'),
  detailScreen: require('./images/detailScreen.png'),
  Rating: require('./images/Rate.png'),
  productbg: require('./images/productbg.png'),
  bellIcon: require('./images/bell.png'),
  filter: require('./images/filter.png'),
  menuIcon: require('./images/menuIcon.png'),
  delivery: require('./images/delivery.png'),
  confirm: require('./images/confirm.png'),
  history: require('./images/history.png'),
};
